"""
Бенчмарк SQL-запросов АИС «Уют».

Меряет ТОЛЬКО скорость выполнения SQL в БД (SQLite). HTTP-адреса/страницы
не запрашиваются и не замеряются — маршрут и метод нужны лишь для того,
чтобы было видно, какой запрос какой страницей сайта выполняется.

Для каждого маршрута отчёт показывает:
    * метод (GET / POST) и путь маршрута;
    * сколько SQL-запросов он выполняет за один вызов;
    * время каждого запроса (avg / min / max / median) и число строк;
    * суммарное время SQL на один вызов маршрута.

Бенчмарк только читает: соединение открыто с PRAGMA query_only = ON,
а в каталоге только SELECT. Произвольного SQL нет.
Запросов по адресам клиентов (колонка «Адрес») в каталоге нет.

Запуск:
    python sql_benchmark.py                 # все маршруты, 5 повторов
    python sql_benchmark.py --runs 50
    python sql_benchmark.py --route /admin/dashboard
    python sql_benchmark.py --method GET
    python sql_benchmark.py --detail        # + SQL-текст каждого запроса
    python sql_benchmark.py --json

Из кода:
    from sql_benchmark import run_benchmark, catalog_stats
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Optional, Sequence

try:
    from db import get_db, DB_NAME
except ImportError:  # запуск отдельно от проекта
    import os
    import sqlite3

    DB_NAME = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hotel_management.db")

    def get_db():
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row
        return conn

MAX_RUNS = 1000


# ---------------------------------------------------------------------------
# Каталог: маршрут -> SQL-запросы, которые он выполняет (копия реальных запросов
# из routes/*.py, только чтение).
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Q:
    name: str
    sql: str
    params: tuple = ()


@dataclass(frozen=True)
class Route:
    method: str
    path: str
    title: str
    queries: tuple


def _samples(conn=None) -> dict[str, Any]:
    """Реальные значения параметров из БД (чтобы запросы били по существующим данным)."""
    s: dict[str, Any] = {
        "today": date.today().isoformat(),
        "d_from": date.today().isoformat(),
        "d_to": (date.today() + timedelta(days=14)).isoformat(),
        "client_id": "", "phone": "", "room_id": "", "booking_id": "", "login": "", "last": "",
    }
    if conn is None:
        return s
    def one(sql):
        try:
            row = conn.execute(sql).fetchone()
            return row[0] if row else ""
        except Exception:
            return ""
    s["client_id"] = one("SELECT ID_Клиента FROM Клиенты ORDER BY Код LIMIT 1")
    s["phone"] = one("SELECT Телефон FROM Клиенты ORDER BY Код LIMIT 1")
    s["last"] = one("SELECT Фамилия FROM Клиенты ORDER BY Код LIMIT 1")
    s["room_id"] = one("SELECT ID_Номера FROM Номера ORDER BY Код LIMIT 1")
    s["booking_id"] = one("SELECT ID_Бронирования FROM Бронирования ORDER BY Код LIMIT 1")
    s["login"] = one("SELECT Логин FROM Пользователи WHERE Роль='client' LIMIT 1")
    # клиент, у которого есть бронь (для профиля/карточки гостя)
    cid = one("SELECT ID_Клиента FROM Бронирования ORDER BY Код LIMIT 1")
    if cid:
        s["client_id"] = cid
    return s


def build_catalog(s: Optional[dict] = None) -> list[Route]:
    s = s or _samples()
    ACT = "('Подтверждено','Заселен')"
    return [
        # ---------------- публичная часть ----------------
        Route("GET", "/", "Главная", (
            Q("Категории номеров", "SELECT DISTINCT Категория FROM Номера ORDER BY Категория"),
            Q("Список номеров", """SELECT * FROM Номера ORDER BY CASE Статус WHEN 'Свободен' THEN 1
                WHEN 'Будет занят' THEN 2 WHEN 'Занят' THEN 3 END, Номер_Комнаты"""),
        )),
        Route("GET", "/search", "Поиск номеров", (
            Q("Номера по вместимости и датам", f"""SELECT n.* FROM Номера n WHERE n.Вместимость >= ?
                AND NOT EXISTS (SELECT 1 FROM Бронирования b WHERE b.ID_Номера = n.ID_Номера
                AND b.Статус IN {ACT} AND NOT (b.Дата_выезда <= ? OR b.Дата_заезда >= ?))
                ORDER BY n.Цена_за_сутки, n.Номер_Комнаты""", (2, s["d_from"], s["d_to"])),
            Q("Категории номеров", "SELECT DISTINCT Категория FROM Номера ORDER BY Категория"),
        )),
        Route("GET", "/availability", "Проверка доступности", (
            Q("Свободные номера на даты", f"""SELECT n.* FROM Номера n WHERE n.Вместимость>=?
                AND NOT EXISTS (SELECT 1 FROM Бронирования b WHERE b.ID_Номера=n.ID_Номера
                AND b.Статус IN {ACT} AND NOT (b.Дата_выезда<=? OR b.Дата_заезда>=?))
                ORDER BY n.Цена_за_сутки""", (2, s["d_from"], s["d_to"])),
        )),
        Route("GET", "/room/<room_id>", "Карточка номера", (
            Q("Номер", "SELECT * FROM Номера WHERE ID_Номера = ?", (s["room_id"],)),
            Q("Галерея", "SELECT * FROM Галерея_номеров WHERE ID_Номера=? ORDER BY ID", (s["room_id"],)),
            Q("Отзывы", """SELECT r.*,c.Имя FROM Отзывы r JOIN Клиенты c ON c.ID_Клиента=r.ID_Клиента
                WHERE r.ID_Номера=? AND r.Опубликовано=1 ORDER BY r.ID DESC""", (s["room_id"],)),
            Q("Средний рейтинг", """SELECT COALESCE(AVG(Оценка),0) avg, COUNT(*) count FROM Отзывы
                WHERE ID_Номера=? AND Опубликовано=1""", (s["room_id"],)),
            Q("Избранное", "SELECT 1 FROM Избранное WHERE ID_Клиента=? AND ID_Номера=?",
              (s["client_id"], s["room_id"])),
        )),
        # ---------------- гость ----------------
        Route("POST", "/login", "Вход (проверка логина)", (
            Q("Состояние попыток входа",
              "SELECT Неудачные_попытки, Заблокировано_до FROM Попытки_входа WHERE Идентификатор=? AND IP=?",
              (str(s["login"]).lower(), "127.0.0.1")),
            Q("Пользователь по логину", """SELECT u.ID_Клиента, u.Роль, u.Пароль, c.Фамилия, c.Имя, c.Отчество
                FROM Пользователи u LEFT JOIN Клиенты c ON u.ID_Клиента = c.ID_Клиента
                WHERE u.Логин = ?""", (s["login"],)),
        )),
        Route("GET", "/profile", "Профиль гостя", (
            Q("Клиент", "SELECT * FROM Клиенты WHERE ID_Клиента = ?", (s["client_id"],)),
            Q("Брони клиента", """SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) AS days_count
                FROM Бронирования b JOIN Номера n ON b.ID_Номера = n.ID_Номера
                WHERE b.ID_Клиента = ? ORDER BY b.Дата_заезда DESC""", (s["client_id"],)),
        )),
        Route("GET", "/booking/confirmation/<booking_id>", "Подтверждение брони", (
            Q("Бронь + номер + клиент", """SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                CAST(JULIANDAY(b.Дата_выезда) - JULIANDAY(b.Дата_заезда) AS INTEGER) AS days_count,
                c.Фамилия, c.Имя, c.Отчество FROM Бронирования b
                JOIN Номера n ON b.ID_Номера=n.ID_Номера JOIN Клиенты c ON b.ID_Клиента=c.ID_Клиента
                WHERE b.ID_Бронирования=? AND b.ID_Клиента=?""", (s["booking_id"], s["client_id"])),
            Q("Счёт", "SELECT * FROM Счета WHERE ID_Бронирования=?", (s["booking_id"],)),
            Q("Услуги брони", """SELECT u.*, bs.Количество, bs.Цена AS Цена_при_бронировании
                FROM Бронирование_Услуги bs JOIN Услуги u ON u.ID_Услуги=bs.ID_Услуги
                WHERE bs.ID_Бронирования=?""", (s["booking_id"],)),
        )),
        Route("GET", "/booking/<room_id>", "Форма бронирования", (
            Q("Номер", "SELECT * FROM Номера WHERE ID_Номера = ?", (s["room_id"],)),
            Q("Активные услуги", "SELECT * FROM Услуги WHERE Активна=1 ORDER BY Название"),
        )),
        # ---------------- админ-панель ----------------
        Route("GET", "/admin/dashboard", "Дашборд", (
            Q("Всего клиентов", "SELECT COUNT(*) FROM Клиенты"),
            Q("Всего номеров", "SELECT COUNT(*) FROM Номера"),
            Q("Свободных номеров", "SELECT COUNT(*) FROM Номера WHERE Статус='Свободен'"),
            Q("Занятых номеров", "SELECT COUNT(*) FROM Номера WHERE Статус='Занят'"),
            Q("Будет занято", "SELECT COUNT(*) FROM Номера WHERE Статус='Будет занят'"),
            Q("Активных броней", f"SELECT COUNT(*) FROM Бронирования WHERE Статус IN {ACT}"),
            Q("Заезды сегодня", "SELECT COUNT(*) FROM Бронирования WHERE Статус='Подтверждено' AND Дата_заезда=?", (s["today"],)),
            Q("Выезды сегодня", "SELECT COUNT(*) FROM Бронирования WHERE Статус='Заселен' AND Дата_выезда=?", (s["today"],)),
            Q("Выручка", """SELECT COALESCE(SUM(Сумма_проживание),0) FROM Счета s
                JOIN Бронирования b ON b.ID_Бронирования=s.ID_Бронирования WHERE b.Статус!='Отменено'"""),
            Q("Оплачено", "SELECT COALESCE(SUM(Сумма_проживание),0) FROM Счета WHERE Оплачено=1"),
            Q("Ближайшие заезды", """SELECT b.*, n.Номер_Комнаты, c.Фамилия, c.Имя, c.Телефон
                FROM Бронирования b JOIN Номера n ON n.ID_Номера=b.ID_Номера
                JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
                WHERE b.Статус='Подтверждено' AND b.Дата_заезда >= ?
                ORDER BY b.Дата_заезда, n.Номер_Комнаты LIMIT 8""", (s["today"],)),
            Q("Последние брони", """SELECT b.*, n.Номер_Комнаты, c.Фамилия, c.Имя, c.Телефон
                FROM Бронирования b JOIN Номера n ON n.ID_Номера=b.ID_Номера
                JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента ORDER BY b.Код DESC LIMIT 10"""),
            Q("Номера по категориям", """SELECT Категория, COUNT(*) total,
                SUM(CASE WHEN Статус='Свободен' THEN 1 ELSE 0 END) free,
                SUM(CASE WHEN Статус='Занят' THEN 1 ELSE 0 END) occupied,
                SUM(CASE WHEN Статус='Будет занят' THEN 1 ELSE 0 END) future
                FROM Номера GROUP BY Категория ORDER BY Категория"""),
        )),
        Route("GET", "/admin/rooms", "Номера (админ)", (
            Q("Номера + ближайший гость", f"""SELECT n.*,
                (SELECT c.Фамилия || ' ' || c.Имя FROM Бронирования b JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
                  WHERE b.ID_Номера=n.ID_Номера AND b.Статус IN {ACT} ORDER BY b.Дата_заезда LIMIT 1) next_guest,
                (SELECT b.Дата_заезда FROM Бронирования b
                  WHERE b.ID_Номера=n.ID_Номера AND b.Статус IN {ACT} ORDER BY b.Дата_заезда LIMIT 1) next_checkin
                FROM Номера n ORDER BY CAST(n.Номер_Комнаты AS INTEGER), n.Номер_Комнаты"""),
        )),
        Route("GET", "/admin/bookings", "Бронирования", (
            Q("Список броней (JOIN номер + клиент + счёт)", """SELECT b.*, n.Номер_Комнаты, n.Категория, n.Цена_за_сутки,
                c.Фамилия, c.Имя, c.Телефон, s.Оплачено, s.Сумма_проживание
                FROM Бронирования b JOIN Номера n ON n.ID_Номера=b.ID_Номера
                JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
                LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования
                WHERE 1=1 ORDER BY b.Дата_заезда DESC, b.Код DESC"""),
        )),
        Route("GET", "/admin/booking/add", "Новая бронь (форма)", (
            Q("Все клиенты", "SELECT * FROM Клиенты ORDER BY Фамилия, Имя"),
            Q("Все номера", "SELECT * FROM Номера ORDER BY CAST(Номер_Комнаты AS INTEGER), Номер_Комнаты"),
            Q("Активные услуги", "SELECT * FROM Услуги WHERE Активна=1 ORDER BY Название"),
        )),
        Route("GET", "/admin/clients", "Гости", (
            Q("Список гостей", "SELECT * FROM Клиенты ORDER BY Фамилия,Имя"),
        )),
        Route("GET", "/admin/clients?search=…", "Гости: поиск", (
            Q("Поиск по фамилии / имени / телефону",
              "SELECT * FROM Клиенты WHERE Фамилия LIKE ? OR Имя LIKE ? OR Телефон LIKE ? ORDER BY Фамилия,Имя",
              (f"%{s['last']}%",) * 3),
        )),
        Route("GET", "/admin/client/<client_id>", "Карточка гостя", (
            Q("Клиент", "SELECT * FROM Клиенты WHERE ID_Клиента=?", (s["client_id"],)),
            Q("Брони клиента", """SELECT b.*,n.Номер_Комнаты,n.Категория,s.Сумма_проживание,s.Оплачено
                FROM Бронирования b JOIN Номера n ON n.ID_Номера=b.ID_Номера
                LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования
                WHERE b.ID_Клиента=? ORDER BY b.Дата_заезда DESC""", (s["client_id"],)),
        )),
        Route("POST", "/admin/client/add", "Новый гость (проверка телефона)", (
            Q("Дубликат по телефону", "SELECT 1 FROM Клиенты WHERE Телефон=?", (s["phone"],)),
        )),
        Route("GET", "/admin/calendar", "Календарь", (
            Q("Все номера", "SELECT * FROM Номера ORDER BY CAST(Номер_Комнаты AS INTEGER), Номер_Комнаты"),
            Q("Брони за 14 дней", f"""SELECT b.ID_Бронирования,b.ID_Номера,b.Дата_заезда,b.Дата_выезда,b.Статус,c.Фамилия,c.Имя
                FROM Бронирования b JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
                WHERE b.Статус IN {ACT} AND b.Дата_выезда > ? AND b.Дата_заезда < ?""", (s["d_from"], s["d_to"])),
        )),
        Route("GET", "/admin/reports", "Отчёты", (
            Q("Номера по категориям", """SELECT Категория,COUNT(*) count,AVG(Цена_за_сутки) avg_price,
                SUM(CASE WHEN Статус='Свободен' THEN 1 ELSE 0 END) free FROM Номера GROUP BY Категория ORDER BY Категория"""),
            Q("Статистика по месяцам", """SELECT strftime('%Y-%m',Дата_заезда) month,COUNT(*) count,
                COALESCE(SUM(s.Сумма_проживание),0) revenue FROM Бронирования b
                LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования
                WHERE b.Статус!='Отменено' GROUP BY month ORDER BY month DESC LIMIT 12"""),
            Q("Финансовая сводка", """SELECT COUNT(*) total_bookings,COALESCE(SUM(s.Сумма_проживание),0) total_amount,
                COALESCE(SUM(CASE WHEN s.Оплачено=1 THEN s.Сумма_проживание ELSE 0 END),0) paid_amount
                FROM Бронирования b LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования
                WHERE b.Статус!='Отменено'"""),
        )),
        Route("GET", "/admin/reports/export.csv", "Экспорт отчёта CSV", (
            Q("Выгрузка броней со счетами", """SELECT b.ID_Бронирования,c.Фамилия||' '||c.Имя guest,n.Номер_Комнаты,
                b.Дата_заезда,b.Дата_выезда,b.Количество_гостей,b.Статус,COALESCE(s.Сумма_проживание,0) total,
                CASE WHEN s.Оплачено=1 THEN 'Да' ELSE 'Нет' END paid
                FROM Бронирования b JOIN Клиенты c ON c.ID_Клиента=b.ID_Клиента
                JOIN Номера n ON n.ID_Номера=b.ID_Номера
                LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования ORDER BY b.Дата_заезда DESC"""),
        )),
        Route("GET", "/admin/finance", "Финансы", (
            Q("Итоги", """SELECT COUNT(*) bookings,
                COALESCE(SUM(CASE WHEN b.Статус!='Отменено' THEN s.Сумма_проживание ELSE 0 END),0) revenue,
                COALESCE(SUM(CASE WHEN b.Статус!='Отменено' AND s.Оплачено=1 THEN s.Сумма_проживание ELSE 0 END),0) paid,
                COALESCE(SUM(CASE WHEN b.Статус!='Отменено' AND s.Оплачено=0 THEN s.Сумма_проживание ELSE 0 END),0) debt
                FROM Бронирования b LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования"""),
            Q("По способам оплаты", """SELECT COALESCE(Способ_оплаты,'Не указан') method, COUNT(*) count,
                COALESCE(SUM(Сумма_проживание),0) amount FROM Счета WHERE Оплачено=1
                GROUP BY Способ_оплаты ORDER BY amount DESC"""),
            Q("По месяцам", """SELECT strftime('%Y-%m', b.Дата_заезда) month, COUNT(*) count,
                COALESCE(SUM(s.Сумма_проживание),0) amount FROM Бронирования b
                LEFT JOIN Счета s ON s.ID_Бронирования=b.ID_Бронирования
                WHERE b.Статус!='Отменено' GROUP BY month ORDER BY month DESC LIMIT 12"""),
        )),
        Route("GET", "/admin/journal", "Журнал действий", (
            Q("Последние 300 записей", "SELECT * FROM Журнал_действий ORDER BY ID DESC LIMIT 300"),
        )),
    ]


def catalog_stats() -> dict[str, int]:
    """Сколько маршрутов и SQL-запросов в наборе (без обращения к БД)."""
    cat = build_catalog()
    return {
        "routes": len(cat),
        "queries": sum(len(r.queries) for r in cat),
        "get": sum(1 for r in cat if r.method == "GET"),
        "post": sum(1 for r in cat if r.method == "POST"),
    }


# ---------------------------------------------------------------------------
# Замер
# ---------------------------------------------------------------------------
@dataclass
class QueryResult:
    name: str
    sql: str
    params: tuple
    times_ms: list = field(default_factory=list)
    rows: int = 0
    error: Optional[str] = None

    @property
    def avg_ms(self) -> float:
        return statistics.mean(self.times_ms) if self.times_ms else 0.0

    @property
    def min_ms(self) -> float:
        return min(self.times_ms) if self.times_ms else 0.0

    @property
    def max_ms(self) -> float:
        return max(self.times_ms) if self.times_ms else 0.0

    @property
    def median_ms(self) -> float:
        return statistics.median(self.times_ms) if self.times_ms else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "sql": " ".join(self.sql.split()),
            "params": list(self.params),
            "avg_ms": round(self.avg_ms, 4),
            "min_ms": round(self.min_ms, 4),
            "max_ms": round(self.max_ms, 4),
            "median_ms": round(self.median_ms, 4),
            "rows": self.rows,
            "error": self.error,
        }


@dataclass
class RouteResult:
    method: str
    path: str
    title: str
    runs: int
    queries: list = field(default_factory=list)

    @property
    def query_count(self) -> int:
        return len(self.queries)

    @property
    def total_avg_ms(self) -> float:
        return sum(q.avg_ms for q in self.queries if not q.error)

    @property
    def errors(self) -> int:
        return sum(1 for q in self.queries if q.error)

    def to_dict(self) -> dict[str, Any]:
        return {
            "method": self.method,
            "path": self.path,
            "title": self.title,
            "runs": self.runs,
            "query_count": self.query_count,
            "executions": self.query_count * self.runs,
            "total_avg_ms": round(self.total_avg_ms, 4),
            "errors": self.errors,
            "queries": [q.to_dict() for q in self.queries],
        }


def _open_readonly():
    conn = get_db()
    conn.execute("PRAGMA query_only = ON")  # бенчмарк физически не может менять данные
    return conn


def _measure(conn, q: Q, runs: int, warmup: int = 1) -> QueryResult:
    res = QueryResult(q.name, q.sql, tuple(q.params))
    try:
        for _ in range(warmup):
            conn.execute(q.sql, q.params).fetchall()
        for _ in range(runs):
            t0 = time.perf_counter()
            rows = conn.execute(q.sql, q.params).fetchall()
            res.times_ms.append((time.perf_counter() - t0) * 1000.0)
            res.rows = len(rows)
    except Exception as exc:  # noqa: BLE001 — показываем ошибку в отчёте
        res.error = str(exc)
    return res


def run_benchmark(
    runs: int = 5,
    method: Optional[str] = None,
    route: Optional[str] = None,
) -> list[RouteResult]:
    """Прогоняет SQL всех маршрутов (или отфильтрованных по методу / пути)."""
    runs = max(1, min(MAX_RUNS, int(runs)))
    conn = _open_readonly()
    out: list[RouteResult] = []
    try:
        for r in build_catalog(_samples(conn)):
            if method and r.method != method.upper():
                continue
            if route and route not in r.path:
                continue
            rr = RouteResult(r.method, r.path, r.title, runs)
            for q in r.queries:
                rr.queries.append(_measure(conn, q, runs))
            out.append(rr)
    finally:
        conn.close()
    return out


def summarize(results: list[RouteResult]) -> dict[str, Any]:
    runs = results[0].runs if results else 0
    qn = sum(r.query_count for r in results)
    return {
        "routes": len(results),
        "queries": qn,
        "runs": runs,
        "executions": qn * runs,
        "total_avg_ms": round(sum(r.total_avg_ms for r in results), 4),
        "errors": sum(r.errors for r in results),
    }


# ---------------------------------------------------------------------------
# Текстовый отчёт / CLI
# ---------------------------------------------------------------------------
def format_report(results: list[RouteResult], detail: bool = False) -> str:
    sm = summarize(results)
    w = 78
    lines = [
        "=" * w,
        "  SQL Benchmark — АИС «Уют» (скорость SQL в БД)",
        f"  БД: {DB_NAME}",
        f"  Маршрутов: {sm['routes']} · SQL-запросов: {sm['queries']} · "
        f"повторов: {sm['runs']} · выполнений: {sm['executions']}",
        "=" * w,
        f"{'Метод':<6} {'Маршрут':<38} {'Запросов':>8} {'SQL на вызов':>13} {'Ошибок':>7}",
        "-" * w,
    ]
    for r in results:
        lines.append(f"{r.method:<6} {r.path[:38]:<38} {r.query_count:>8} {r.total_avg_ms:>10.3f} мс {r.errors:>7}")
        if detail:
            for q in r.queries:
                if q.error:
                    lines.append(f"         └ {q.name}: ОШИБКА {q.error}")
                else:
                    lines.append(
                        f"         └ {q.name[:36]:<36} avg {q.avg_ms:7.3f}  min {q.min_ms:7.3f}  "
                        f"max {q.max_ms:7.3f} мс  строк {q.rows}"
                    )
                    lines.append(f"           SQL: {' '.join(q.sql.split())[:150]}")
    lines += ["-" * w, f"Итого SQL на один проход по всем маршрутам: {sm['total_avg_ms']:.3f} мс", "=" * w]
    return "\n".join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Скорость SQL-запросов АИС «Уют» по маршрутам")
    p.add_argument("--runs", "-n", type=int, default=5, help=f"повторов каждого запроса (1..{MAX_RUNS}, default 5)")
    p.add_argument("--method", "-m", choices=["GET", "POST", "get", "post"], help="только этот HTTP-метод")
    p.add_argument("--route", "-r", help="только маршруты, содержащие эту строку")
    p.add_argument("--detail", "-d", action="store_true", help="показать каждый запрос и его SQL")
    p.add_argument("--json", action="store_true", help="вывод в JSON")
    a = p.parse_args(argv)

    results = run_benchmark(a.runs, a.method, a.route)
    if a.json:
        print(json.dumps({"summary": summarize(results), "routes": [r.to_dict() for r in results]},
                         ensure_ascii=False, indent=2))
    else:
        print(format_report(results, a.detail))
    return 0 if all(r.errors == 0 for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
