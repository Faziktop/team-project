"""
Сервис отправки email для отеля «Уют» / ONYX Hotel.

Использует Flask-Mail. Настройки берутся из переменных окружения
(см. .env.example). Если SMTP не настроен, письма логируются в консоль
и не прерывают основную бизнес-логику (booking / contact / notify).
"""
from __future__ import annotations

import logging
import os
import re
from typing import Optional

from flask import current_app, render_template_string
from flask_mail import Mail, Message

logger = logging.getLogger(__name__)

mail = Mail()

# Простая проверка формата email
_EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")


def is_valid_email(value: Optional[str]) -> bool:
    if not value or not isinstance(value, str):
        return False
    return bool(_EMAIL_RE.match(value.strip()))


def init_mail(app) -> None:
    """Подключает Flask-Mail к приложению. Вызывается один раз из app.py."""
    app.config.setdefault("MAIL_SERVER", os.environ.get("MAIL_SERVER", "smtp.gmail.com"))
    app.config.setdefault("MAIL_PORT", int(os.environ.get("MAIL_PORT", "587")))
    app.config.setdefault("MAIL_USE_TLS", os.environ.get("MAIL_USE_TLS", "1") == "1")
    app.config.setdefault("MAIL_USE_SSL", os.environ.get("MAIL_USE_SSL", "0") == "1")
    app.config.setdefault("MAIL_USERNAME", os.environ.get("MAIL_USERNAME", ""))
    app.config.setdefault("MAIL_PASSWORD", os.environ.get("MAIL_PASSWORD", ""))
    app.config.setdefault(
        "MAIL_DEFAULT_SENDER",
        os.environ.get("MAIL_DEFAULT_SENDER")
        or os.environ.get("MAIL_USERNAME")
        or "noreply@onyx-hotel.ru",
    )
    app.config.setdefault("MAIL_SUPPRESS_SEND", os.environ.get("MAIL_SUPPRESS_SEND", "0") == "1")
    # Адрес, на который приходят сообщения с формы «Контакты»
    app.config.setdefault(
        "MAIL_ADMIN_RECIPIENT",
        os.environ.get("MAIL_ADMIN_RECIPIENT")
        or os.environ.get("MAIL_USERNAME")
        or "info@onyx-hotel.ru",
    )
    mail.init_app(app)


def _mail_configured() -> bool:
    """True, если заданы минимально необходимые SMTP-параметры."""
    try:
        cfg = current_app.config
        return bool(cfg.get("MAIL_USERNAME") and cfg.get("MAIL_PASSWORD"))
    except RuntimeError:
        return False


def send_email(
    to: str,
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> bool:
    """
    Отправляет одно письмо.

    Возвращает True при успехе, False при ошибке / отсутствии настроек.
    Никогда не поднимает исключение наружу — чтобы не ломать бронирование.
    """
    to = (to or "").strip()
    if not is_valid_email(to):
        logger.warning("send_email: некорректный адрес получателя: %r", to)
        return False

    try:
        msg = Message(
            subject=subject,
            recipients=[to],
            html=html_body,
            body=text_body or _html_to_text(html_body),
            reply_to=reply_to,
        )
        if not _mail_configured() or current_app.config.get("MAIL_SUPPRESS_SEND"):
            logger.info(
                "[EMAIL DEMO] To=%s Subject=%s\n%s",
                to,
                subject,
                text_body or _html_to_text(html_body)[:500],
            )
            # В демо-режиме считаем отправку «успешной», чтобы UI показывал успех
            return True

        mail.send(msg)
        logger.info("Email отправлен: to=%s subject=%s", to, subject)
        return True
    except Exception as exc:
        logger.exception("Ошибка отправки email to=%s: %s", to, exc)
        return False


def _html_to_text(html: str) -> str:
    """Грубая конвертация HTML → plain text для multipart."""
    text = re.sub(r"<br\s*/?>", "\n", html, flags=re.I)
    text = re.sub(r"</p>", "\n\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


# ---------------------------------------------------------------------------
# Готовые шаблоны писем
# ---------------------------------------------------------------------------

_BOOKING_HTML = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; line-height: 1.5; color: #222;">
  <div style="max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e0e0e0; border-radius: 8px;">
    <h2 style="color: #1a1a2e; margin-top: 0;">Подтверждение бронирования</h2>
    <p>Здравствуйте, {{ guest_name }}!</p>
    <p>Ваше бронирование в отеле <strong>ONYX Hotel («Уют»)</strong> успешно создано.</p>
    <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Номер брони</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ booking_id }}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Номер комнаты</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ room_number }} ({{ category }})</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Заезд</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ check_in }}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Выезд</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ check_out }}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Гостей</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ guests }}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Сумма</strong></td>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">{{ total }} ₽</td></tr>
      <tr><td style="padding: 8px;"><strong>Предоплата 30%</strong></td>
          <td style="padding: 8px;">{{ prepayment }} ₽</td></tr>
    </table>
    <p style="color: #555; font-size: 14px;">
      Бесплатная отмена — за 24 часа до заезда. По вопросам: +7 (495) 123-45-67, booking@onyx-hotel.ru
    </p>
    <p style="margin-bottom: 0;">С уважением,<br>Команда ONYX Hotel</p>
  </div>
</body>
</html>
"""

_CONTACT_ADMIN_HTML = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; line-height: 1.5;">
  <h2>Сообщение с сайта ONYX Hotel</h2>
  <p><strong>Имя:</strong> {{ name }}</p>
  <p><strong>Email:</strong> {{ email }}</p>
  <p><strong>Телефон:</strong> {{ phone }}</p>
  <p><strong>Тема:</strong> {{ subject }}</p>
  <hr>
  <p style="white-space: pre-wrap;">{{ message }}</p>
</body>
</html>
"""

_WELCOME_HTML = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; line-height: 1.5; color: #222;">
  <div style="max-width: 600px; margin: 0 auto; padding: 24px;">
    <h2>Добро пожаловать в ONYX Hotel!</h2>
    <p>Здравствуйте, {{ guest_name }}!</p>
    <p>Вы успешно зарегистрировались. Логин для входа — ваш номер телефона:
       <strong>{{ phone }}</strong>.</p>
    <p>В личном кабинете вы можете бронировать номера, смотреть историю и управлять профилем.</p>
    <p style="margin-bottom: 0;">С уважением,<br>Команда ONYX Hotel</p>
  </div>
</body>
</html>
"""


def send_booking_confirmation(
    to_email: str,
    guest_name: str,
    booking_id: str,
    room_number: str,
    category: str,
    check_in: str,
    check_out: str,
    guests: int,
    total: float,
    prepayment: float,
) -> bool:
    """Письмо гостю после создания брони."""
    html = render_template_string(
        _BOOKING_HTML,
        guest_name=guest_name or "Гость",
        booking_id=booking_id,
        room_number=room_number,
        category=category,
        check_in=check_in,
        check_out=check_out,
        guests=guests,
        total=f"{total:.0f}",
        prepayment=f"{prepayment:.0f}",
    )
    return send_email(
        to=to_email,
        subject=f"Бронирование {booking_id} подтверждено — ONYX Hotel",
        html_body=html,
    )


def send_contact_message_to_admin(
    name: str,
    email: str,
    phone: str,
    subject: str,
    message: str,
) -> bool:
    """Пересылает сообщение с формы «Контакты» на адрес администратора."""
    admin = current_app.config.get("MAIL_ADMIN_RECIPIENT") or "info@onyx-hotel.ru"
    html = render_template_string(
        _CONTACT_ADMIN_HTML,
        name=name,
        email=email,
        phone=phone or "—",
        subject=subject or "Без темы",
        message=message,
    )
    return send_email(
        to=admin,
        subject=f"[Сайт] {subject or 'Сообщение'}: {name}",
        html_body=html,
        reply_to=email if is_valid_email(email) else None,
    )


def send_welcome_email(to_email: str, guest_name: str, phone: str) -> bool:
    """Приветственное письмо после регистрации."""
    html = render_template_string(
        _WELCOME_HTML,
        guest_name=guest_name or "Гость",
        phone=phone,
    )
    return send_email(
        to=to_email,
        subject="Добро пожаловать в ONYX Hotel!",
        html_body=html,
    )


def send_notification_email(to_email: str, title: str, text: str) -> bool:
    """Дублирует in-app уведомление на почту."""
    html = f"""
    <html><body style="font-family: Arial, sans-serif;">
      <h3>{title}</h3>
      <p style="white-space: pre-wrap;">{text}</p>
      <p style="color:#888;font-size:13px;">Это уведомление из личного кабинета ONYX Hotel.</p>
    </body></html>
    """
    return send_email(to=to_email, subject=title, html_body=html)
