"""Единая точка изменения остатков склада и связанных движений.

Все публичные функции работают ВНУТРИ уже открытой транзакции
(`BEGIN IMMEDIATE` вызывающего кода). Модуль не открывает и не
закрывает транзакции самостоятельно.

Зачем это нужно:
  Раньше логика списания склада была продублирована в
  `orders.send_to_kitchen`, `orders.cancel`, `warehouse.movement` и
  `warehouse.update_request_status`. Любое изменение инварианта
  (например, «остаток не может стать отрицательным») требовало
  синхронной правки в четырёх местах. Теперь — в одном.
"""
from collections import defaultdict

from db import get_db


_ALLOWED_REASONS = ("receipt", "writeoff", "inventory", "order")


def _validate_reason(reason: str) -> None:
    if reason not in _ALLOWED_REASONS:
        raise ValueError(
            f"Недопустимый reason={reason!r}; "
            f"ожидается одно из {_ALLOWED_REASONS}"
        )


# ---------------------------------------------------------------------------
# Базовые примитивы
# ---------------------------------------------------------------------------
def apply_stock_movement(
    ingredient_id: int,
    qty_change: float,
    reason: str,
    *,
    comment: str | None = None,
    user_id: int | None = None,
) -> None:
    """Изменить остаток ингредиента на qty_change и записать движение.

    qty_change > 0 — приход; qty_change < 0 — расход.
    reason — один из ('receipt', 'writeoff', 'inventory', 'order'),
    строго соответствует CHECK-констрейнту stock_movements.reason.

    Транзакция — забота вызывающего.
    """
    _validate_reason(reason)
    db = get_db()
    db.execute(
        "UPDATE ingredients SET stock_qty = stock_qty + ? WHERE id = ?",
        (qty_change, ingredient_id),
    )
    db.execute(
        "INSERT INTO stock_movements "
        "(ingredient_id, qty_change, reason, comment, user_id) "
        "VALUES (?, ?, ?, ?, ?)",
        (ingredient_id, qty_change, reason, comment, user_id),
    )


def set_stock_absolute(
    ingredient_id: int,
    new_qty: float,
    reason: str,
    *,
    comment: str | None = None,
    user_id: int | None = None,
) -> float:
    """Установить остаток в new_qty (используется для инвентаризации).

    Пишет движение с qty_change = new_qty - текущий_остаток.
    Если разница < 1e-12 — движение не пишется (нет изменения).

    Возвращает фактическое изменение (может быть 0.0).
    """
    _validate_reason(reason)
    db = get_db()
    row = db.execute(
        "SELECT stock_qty FROM ingredients WHERE id = ?", (ingredient_id,)
    ).fetchone()
    if row is None:
        raise ValueError(f"Ингредиент #{ingredient_id} не найден")

    change = float(new_qty) - float(row["stock_qty"])
    if abs(change) < 1e-12:
        return 0.0

    db.execute(
        "UPDATE ingredients SET stock_qty = ? WHERE id = ?",
        (new_qty, ingredient_id),
    )
    db.execute(
        "INSERT INTO stock_movements "
        "(ingredient_id, qty_change, reason, comment, user_id) "
        "VALUES (?, ?, ?, ?, ?)",
        (ingredient_id, change, reason, comment, user_id),
    )
    return change


# ---------------------------------------------------------------------------
# Проверка достаточности остатков
# ---------------------------------------------------------------------------
def check_availability(needs: dict[int, float]) -> list[tuple]:
    """Проверить, хватает ли остатков под потребности.

    needs: {ingredient_id: need_qty}.

    Возвращает список дефицитов вида
    [(name, need, have, unit), ...]. Пустой список — всё хватает.

    Отсутствующие в БД ингредиенты тоже попадают в дефицит (это может
    случиться, если техкарту сослали на удалённый ингредиент).
    """
    if not needs:
        return []
    db = get_db()
    ids = list(needs.keys())
    qmarks = ",".join("?" * len(ids))
    rows = db.execute(
        f"SELECT id, name, unit, stock_qty FROM ingredients "
        f"WHERE id IN ({qmarks})",
        ids,
    ).fetchall()
    by_id = {r["id"]: r for r in rows}

    shortages: list[tuple] = []
    for ing_id, need in needs.items():
        row = by_id.get(ing_id)
        if row is None:
            shortages.append((f"#{ing_id}", float(need), 0.0, "?"))
            continue
        if row["stock_qty"] + 1e-9 < need:
            shortages.append(
                (row["name"], float(need),
                 float(row["stock_qty"]), row["unit"])
            )
    return shortages


# ---------------------------------------------------------------------------
# Расчёт потребностей по заказу
# ---------------------------------------------------------------------------
def _tc_by_dish(dish_ids: list[int]) -> dict[int, list]:
    """Вернуть {dish_id: [tech_card_row, ...]} для списка блюд."""
    if not dish_ids:
        return {}
    db = get_db()
    qmarks = ",".join("?" * len(dish_ids))
    rows = db.execute(
        f"SELECT dish_id, ingredient_id, qty_per_portion "
        f"FROM tech_cards WHERE dish_id IN ({qmarks})",
        dish_ids,
    ).fetchall()
    result: dict[int, list] = defaultdict(list)
    for r in rows:
        result[r["dish_id"]].append(r)
    return result


def calc_order_needs(items) -> dict[int, float]:
    """Посчитать потребности ингредиентов для списка позиций заказа.

    items — итерируемое из sqlite3.Row / dict с полями dish_id и qty.
    Возвращает {ingredient_id: total_qty}. Пустой словарь — у блюд
    нет техкарт.
    """
    dish_ids = list({it["dish_id"] for it in items})
    tc_by_dish = _tc_by_dish(dish_ids)

    needs: dict[int, float] = defaultdict(float)
    for item in items:
        for tc in tc_by_dish.get(item["dish_id"], []):
            needs[tc["ingredient_id"]] += tc["qty_per_portion"] * item["qty"]
    return dict(needs)


# ---------------------------------------------------------------------------
# Операции по заказам
# ---------------------------------------------------------------------------
def write_off_for_order(
    order_id: int, items, user_id: int
) -> dict[int, float]:
    """Списать ингредиенты для всех переданных позиций заказа.

    items — позиции заказа (Row/dict с dish_id и qty). Обычно это
    только те позиции, что переходят 'new' → 'cooking'.

    Возвращает {ingredient_id: списанное_кол-во} — для аудита/ответа.
    Ничего не делает, если у блюд нет техкарт.
    """
    dish_ids = list({it["dish_id"] for it in items})
    tc_by_dish = _tc_by_dish(dish_ids)

    written_off: dict[int, float] = defaultdict(float)
    for item in items:
        for tc in tc_by_dish.get(item["dish_id"], []):
            amount = tc["qty_per_portion"] * item["qty"]
            apply_stock_movement(
                tc["ingredient_id"], -amount, "order",
                comment=f"Заказ #{order_id}", user_id=user_id,
            )
            written_off[tc["ingredient_id"]] += amount
    return dict(written_off)


def restore_for_cancelled_order(
    order_id: int, items, user_id: int
) -> dict[int, float]:
    """Восстановить ингредиенты по отменённым позициям заказа.

    items — только те позиции, ингредиенты которых уже были списаны
    (статусы 'cooking' / 'ready'). Для 'new'/'cancelled' ничего не
    списывалось, восстанавливать нечего.

    Возвращает {ingredient_id: возвращённое_кол-во}.
    """
    dish_ids = list({it["dish_id"] for it in items})
    tc_by_dish = _tc_by_dish(dish_ids)

    restored: dict[int, float] = defaultdict(float)
    for item in items:
        for tc in tc_by_dish.get(item["dish_id"], []):
            amount = tc["qty_per_portion"] * item["qty"]
            apply_stock_movement(
                tc["ingredient_id"], amount, "inventory",
                comment=f"Возврат на склад по отмене заказа #{order_id}",
                user_id=user_id,
            )
            restored[tc["ingredient_id"]] += amount
    return dict(restored)


# ---------------------------------------------------------------------------
# Операции по складским движениям и заявкам
# ---------------------------------------------------------------------------
def apply_receipt(
    ingredient_id: int, qty: float, *,
    comment: str | None = None, user_id: int | None = None,
) -> None:
    """Приход: увеличить остаток на qty (>0)."""
    if qty <= 0:
        raise ValueError("Приход должен быть > 0")
    apply_stock_movement(
        ingredient_id, qty, "receipt",
        comment=comment, user_id=user_id,
    )


def apply_writeoff(
    ingredient_id: int, qty: float, *,
    comment: str | None = None, user_id: int | None = None,
) -> None:
    """Списание: уменьшить остаток на qty (>0).

    Бросает ValueError, если на складе меньше, чем qty.
    """
    if qty <= 0:
        raise ValueError("Списание должно быть > 0")
    db = get_db()
    row = db.execute(
        "SELECT stock_qty FROM ingredients WHERE id = ?", (ingredient_id,)
    ).fetchone()
    if row is None:
        raise ValueError(f"Ингредиент #{ingredient_id} не найден")
    if float(row["stock_qty"]) + 1e-9 < qty:
        raise ValueError("Нельзя списать больше, чем есть на складе")
    apply_stock_movement(
        ingredient_id, -qty, "writeoff",
        comment=comment, user_id=user_id,
    )


def apply_inventory(
    ingredient_id: int, new_qty: float, *,
    comment: str, user_id: int | None = None,
) -> float:
    """Инвентаризация: установить абсолютный остаток.

    comment обязателен (обоснование).
    Возвращает фактическое изменение остатка.
    """
    if new_qty < 0:
        raise ValueError("Остаток не может быть отрицательным")
    if not comment:
        raise ValueError("Инвентаризация требует комментария")
    return set_stock_absolute(
        ingredient_id, new_qty, "inventory",
        comment=comment, user_id=user_id,
    )