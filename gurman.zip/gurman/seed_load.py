"""Нагрузочный seed: ~12 000 записей во все рабочие таблицы.

Запуск:
    flask seed-load
    flask seed-load --orders 3000 --days 120 --seed 7

Данные генерируются ПОВЕРХ существующего демо-seed. Справочники
(categories / dishes / ingredients / users) не перезаписываются —
добавляются новые строки с суффиксами, чтобы не нарушить UNIQUE.
"""
import random
from datetime import datetime, timedelta

import click

from db import get_db
from passwords import hash_password


# ---------------------------------------------------------------------------
# Пул имён и значений
# ---------------------------------------------------------------------------
_FIRST_M = ["Александр", "Дмитрий", "Сергей", "Андрей", "Максим", "Иван",
            "Михаил", "Николай", "Артём", "Пётр", "Олег", "Владимир",
            "Роман", "Егор", "Кирилл", "Глеб", "Фёдор", "Матвей"]
_FIRST_F = ["Анна", "Мария", "Елена", "Ольга", "Татьяна", "Ирина",
            "Наталья", "Светлана", "Юлия", "Екатерина", "Кристина",
            "Алиса", "Дарья", "Полина", "София", "Вера", "Ксения", "Марина"]
_LAST_M = ["Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов", "Попов",
           "Волков", "Морозов", "Новиков", "Фёдоров", "Егоров", "Павлов",
           "Козлов", "Степанов", "Николаев", "Орлов", "Андреев", "Макаров"]
_LAST_F = ["Иванова", "Петрова", "Сидорова", "Кузнецова", "Смирнова",
           "Попова", "Волкова", "Морозова", "Новикова", "Фёдорова",
           "Егорова", "Павлова", "Козлова", "Степанова", "Николаева",
           "Орлова", "Андреева", "Макарова"]
_TRANSLIT = {
    'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh',
    'з':'z','и':'i','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o',
    'п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'kh','ц':'ts',
    'ч':'ch','ш':'sh','щ':'shch','ъ':'','ы':'y','ь':'','э':'e',
    'ю':'yu','я':'ya',
}


def _tr(s: str) -> str:
    return "".join(_TRANSLIT.get(c.lower(), c) for c in s)


def _make_login(full_name: str, used: set[str]) -> str:
    """Транслит «Фамилия Имя» → ivanov.a. Гарантирует уникальность."""
    parts = full_name.split()
    family = parts[0] if parts else "user"
    given = parts[1] if len(parts) > 1 else "x"

    base = f"{_tr(family)}.{_tr(given)[:1]}".lower()
    login = base
    n = 1
    while login in used:
        n += 1
        login = f"{base}{n}"
    used.add(login)
    return login

_POSITIONS = ["Официант", "Повар", "Бармен", "Кладовщик", "Бухгалтер",
              "Су-шеф", "Хостес", "Менеджер", "Уборщик", "Курьер"]

_CAT_EXTRA = ["Закуски холодные", "Закуски горячие", "Гриль", "Паста",
              "Пицца", "Ризотто", "Вегетарианское", "Стейки",
              "Морепродукты", "Суши"]

_ING_EXTRA = [
    ("Говядина (вырезка)", "кг"), ("Свинина (шея)", "кг"),
    ("Курица (бедро)", "кг"), ("Индейка (филе)", "кг"),
    ("Лосось (филе)", "кг"), ("Тунец", "кг"),
    ("Креветки", "кг"), ("Мидии", "кг"),
    ("Помидоры черри", "кг"), ("Руккола", "кг"), ("Шпинат", "кг"),
    ("Авокадо", "кг"), ("Сыр Моцарелла", "кг"), ("Сыр Чеддер", "кг"),
    ("Сыр Фета", "кг"), ("Сыр Горгонзола", "кг"),
    ("Мука (в/с)", "кг"), ("Дрожжи", "кг"), ("Оливковое масло", "л"),
    ("Сливочное масло", "кг"), ("Сливки 33%", "л"), ("Молоко 3.2%", "л"),
    ("Яйца", "шт"), ("Сахар", "кг"), ("Соль морская", "кг"),
    ("Перец чёрный", "кг"), ("Специи итальянские", "кг"),
    ("Базилик свежий", "кг"), ("Тимьян", "кг"), ("Розмарин", "кг"),
    ("Чеснок", "кг"), ("Лук красный", "кг"), ("Лук белый", "кг"),
    ("Морковь", "кг"), ("Картофель молодой", "кг"), ("Брокколи", "кг"),
    ("Цветная капуста", "кг"), ("Спаржа", "кг"),
    ("Грибы шампиньоны", "кг"), ("Грибы белые", "кг"),
    ("Рис арборио", "кг"), ("Рис для суши", "кг"),
    ("Спагетти", "кг"), ("Пенне", "кг"),
    ("Хлеб бородинский", "шт"), ("Багет", "шт"),
    ("Вино белое", "л"), ("Вино красное", "л"),
    ("Вода минеральная", "л"),
]

_DISH_WORDS_A = ["Стейк", "Салат", "Суп", "Паста", "Ризотто", "Пицца",
                 "Бургер", "Котлеты", "Жаркое", "Плов", "Карри", "Том Ям",
                 "Лапша", "Роллы", "Суши", "Сэндвич", "Крем-суп", "Шашлык",
                 "Рёбрышки", "Запеканка"]
_DISH_WORDS_B = ["классический", "фирменный", "по-домашнему", "с травами",
                 "в соусе", "на гриле", "запечённый", "острый",
                 "диетический", "с сыром"]

_LOAD_PASSWORD = "LoadTest12345!"


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def _rand_name() -> str:
    if random.random() < 0.5:
        return f"{random.choice(_LAST_M)} {random.choice(_FIRST_M)}"
    return f"{random.choice(_LAST_F)} {random.choice(_FIRST_F)}"


def _rand_phone() -> str:
    return (f"+7 9{random.randint(10, 99)} "
            f"{random.randint(100, 999)}-"
            f"{random.randint(10, 99)}-{random.randint(10, 99)}")


def _rand_dt(days_back: int, hours_span: int = 12) -> str:
    dt = datetime.now() - timedelta(
        days=random.randint(0, days_back),
        hours=random.randint(0, hours_span),
        minutes=random.randint(0, 59),
        seconds=random.randint(0, 59),
    )
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _rand_after(ts: str, min_minutes: int, max_minutes: int) -> str:
    """Прибавить к timestamp случайный интервал в минутах."""
    dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
    dt += timedelta(minutes=random.randint(min_minutes, max_minutes))
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _weighted(choices: list[tuple]) -> str:
    total = sum(w for _, w in choices)
    r = random.uniform(0, total)
    acc = 0.0
    for v, w in choices:
        acc += w
        if r <= acc:
            return v
    return choices[-1][0]


# ---------------------------------------------------------------------------
# Основной сценарий
# ---------------------------------------------------------------------------
def _seed_load(n_orders: int, days: int) -> dict:
    db = get_db()
    stats: dict[str, int] = {}

    # Хеш пароля один раз — 50 пользователей с одним паролем.
    shared_hash = hash_password(_LOAD_PASSWORD)

    db.execute("BEGIN IMMEDIATE")
    try:
        # ---------- 1. users (+50) ----------
        # Нормальные логины вида ivanov.a, petrova.m — с транслитом
        # и защитой от коллизий. Префикс load_ больше не используется.
        existing = {
            r["username"].lower() for r in
            db.execute("SELECT username FROM users").fetchall()
        }
        used = set(existing)

        role_pool = (["waiter"] * 15 + ["cook"] * 10 + ["bartender"] * 8 +
                     ["storekeeper"] * 5 + ["accountant"] * 6 + ["admin"] * 6)
        random.shuffle(role_pool)

        users_data = []
        for role in role_pool:
            full_name = _rand_name()
            login = _make_login(full_name, used)
            users_data.append((login, shared_hash, full_name, role))
        db.executemany(
            "INSERT INTO users (username, password_hash, full_name, role) "
            "VALUES (?, ?, ?, ?)",
            users_data,
        )
        stats["users"] = len(users_data)

        # ---------- 2. restaurant_tables (+20) ----------
        max_num = db.execute(
            "SELECT COALESCE(MAX(number), 0) FROM restaurant_tables"
        ).fetchone()[0]
        tables_data = [
            (max_num + i, random.choice([2, 2, 4, 4, 6, 8]), "free")
            for i in range(1, 21)
        ]
        db.executemany(
            "INSERT INTO restaurant_tables (number, seats, status) "
            "VALUES (?, ?, ?)",
            tables_data,
        )
        stats["restaurant_tables"] = len(tables_data)

        # ---------- 3. categories (+10) ----------
        db.executemany(
            "INSERT OR IGNORE INTO categories (name) VALUES (?)",
            [(n,) for n in _CAT_EXTRA],
        )
        stats["categories"] = len(_CAT_EXTRA)

        # ---------- 4. ingredients (+len _ING_EXTRA) ----------
        ing_data = [
            (name, unit,
             round(random.uniform(0, 200), 2),
             round(random.uniform(5, 30), 2))
            for name, unit in _ING_EXTRA
        ]
        db.executemany(
            "INSERT OR IGNORE INTO ingredients "
            "(name, unit, stock_qty, min_qty) VALUES (?, ?, ?, ?)",
            ing_data,
        )

        # ---------- 4b. Перечитываем id после всех вставок ----------
        all_cat_ids = [r["id"] for r in
                       db.execute("SELECT id FROM categories").fetchall()]
        all_ing_ids = [r["id"] for r in
                       db.execute("SELECT id FROM ingredients").fetchall()]
        stats["ingredients"] = len(all_ing_ids)

        # ---------- 5. dishes (+100) ----------
        dish_data = []
        for i in range(1, 101):
            a = random.choice(_DISH_WORDS_A)
            b = random.choice(_DISH_WORDS_B)
            name = f"{a} {b} #{i}"
            cat_id = random.choice(all_cat_ids)
            price = round(random.uniform(150, 1800), 2)
            station = "bar" if random.random() < 0.15 else "kitchen"
            dish_data.append((name, cat_id, price, station))
        db.executemany(
            "INSERT INTO dishes (name, category_id, price, station) "
            "VALUES (?, ?, ?, ?)",
            dish_data,
        )
        stats["dishes"] = len(dish_data)

        all_dish_ids = [r["id"] for r in
                        db.execute("SELECT id FROM dishes").fetchall()]
        all_dish_prices = {r["id"]: r["price"] for r in
                           db.execute("SELECT id, price FROM dishes").fetchall()}

        # ---------- 6. tech_cards (~250) ----------
        tc_seen: set[tuple] = set()
        tc_data = []
        for _ in range(250):
            did = random.choice(all_dish_ids)
            iid = random.choice(all_ing_ids)
            if (did, iid) in tc_seen:
                continue
            tc_seen.add((did, iid))
            qty = round(random.uniform(0.03, 0.5), 3)
            tc_data.append((did, iid, qty))
        db.executemany(
            "INSERT INTO tech_cards (dish_id, ingredient_id, qty_per_portion) "
            "VALUES (?, ?, ?)",
            tc_data,
        )
        stats["tech_cards"] = len(tc_data)

        # ---------- 7. employees (+50) ----------
        emp_data = []
        for _ in range(50):
            emp_data.append((
                _rand_name(),
                random.choice(_POSITIONS),
                _rand_phone(),
                (datetime.now() - timedelta(days=random.randint(1, 3000))
                 ).strftime("%Y-%m-%d"),
                round(random.uniform(30_000, 120_000), 2),
            ))
        db.executemany(
            "INSERT INTO employees (full_name, position, phone, hired_at, salary) "
            "VALUES (?, ?, ?, ?, ?)",
            emp_data,
        )
        stats["employees"] = len(emp_data)

        all_emp_ids = [r["id"] for r in
                       db.execute("SELECT id FROM employees").fetchall()]

        # ---------- 8. schedule (+500) ----------
        sched_data = []
        for _ in range(500):
            work_date = (datetime.now() - timedelta(
                days=random.randint(0, 30))).strftime("%Y-%m-%d")
            shifts = [("09:00", "18:00"), ("12:00", "22:00"),
                      ("10:00", "20:00"), ("15:00", "23:00"),
                      ("08:00", "16:00")]
            s, e = random.choice(shifts)
            sched_data.append((
                random.choice(all_emp_ids), work_date, s, e,
            ))
        db.executemany(
            "INSERT INTO schedule (employee_id, work_date, shift_start, shift_end) "
            "VALUES (?, ?, ?, ?)",
            sched_data,
        )
        stats["schedule"] = len(sched_data)

        # ---------- 9. orders (+n_orders) ----------
        all_table_ids = [r["id"] for r in
                         db.execute("SELECT id FROM restaurant_tables").fetchall()]
        waiter_ids = [r["id"] for r in db.execute(
            "SELECT id FROM users WHERE role IN ('waiter','admin') "
            "AND username LIKE 'load_%'"
        ).fetchall()]

        max_oid = db.execute(
            "SELECT COALESCE(MAX(id), 0) FROM orders"
        ).fetchone()[0]

        orders_data = []
        order_statuses: list[tuple[int, str, str, str | None]] = []
        for i in range(1, n_orders + 1):
            oid = max_oid + i
            status = _weighted([
                ("paid", 60), ("cancelled", 15), ("open", 10),
                ("sent", 8), ("served", 7),
            ])
            created_at = _rand_dt(days)
            closed_at = None
            if status == "paid":
                closed_at = _rand_after(created_at, 25, 180)
            elif status == "cancelled":
                closed_at = _rand_after(created_at, 5, 90)

            waiter = random.choice(waiter_ids)
            table = random.choice(all_table_ids)
            guests = random.randint(1, 8)

            orders_data.append((
                oid, table, waiter, status, guests, None,
                created_at, closed_at,
            ))
            order_statuses.append((oid, status, created_at, closed_at))

        db.executemany(
            "INSERT INTO orders (id, table_id, waiter_id, status, guests, "
            "comment, created_at, closed_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            orders_data,
        )
        stats["orders"] = len(orders_data)

        # ---------- 10. order_items (~4 на заказ) ----------
        item_rows = []
        item_id = db.execute(
            "SELECT COALESCE(MAX(id), 0) FROM order_items"
        ).fetchone()[0]

        for oid, status, _, _ in order_statuses:
            n_items = random.randint(2, 6)
            for _ in range(n_items):
                item_id += 1
                did = random.choice(all_dish_ids)
                qty = random.randint(1, 4)
                price = all_dish_prices[did]

                if status == "paid":
                    ist = "served"
                elif status == "cancelled":
                    ist = "cancelled"
                elif status == "open":
                    ist = "new"
                elif status == "sent":
                    ist = random.choice(["cooking", "cooking", "ready"])
                else:  # served
                    ist = "served"

                item_rows.append((
                    item_id, oid, did, qty, price, ist, None,
                ))
        db.executemany(
            "INSERT INTO order_items (id, order_id, dish_id, qty, price, "
            "status, comment) VALUES (?, ?, ?, ?, ?, ?, ?)",
            item_rows,
        )
        stats["order_items"] = len(item_rows)

        # ---------- 11. stock_movements (+1500) ----------
        keeper_ids = [r["id"] for r in db.execute(
            "SELECT id FROM users WHERE role IN ('storekeeper','admin')"
        ).fetchall()]

        mov_data = []
        for _ in range(1500):
            ing_id = random.choice(all_ing_ids)
            reason = _weighted([
                ("receipt", 40), ("writeoff", 30),
                ("order", 20), ("inventory", 10),
            ])
            if reason == "receipt":
                qty = round(random.uniform(1, 30), 2)
            elif reason == "writeoff":
                qty = -round(random.uniform(0.5, 10), 2)
            elif reason == "order":
                qty = -round(random.uniform(0.05, 2), 3)
            else:  # inventory
                qty = round(random.uniform(-5, 5), 2)
            comment = {
                "receipt": "Поставка",
                "writeoff": "Списание по акту",
                "order": f"Заказ #нагруз",
                "inventory": "Плановая инвентаризация",
            }[reason]
            mov_data.append((
                ing_id, qty, reason, comment,
                random.choice(keeper_ids),
                _rand_dt(days),
            ))
        db.executemany(
            "INSERT INTO stock_movements (ingredient_id, qty_change, reason, "
            "comment, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            mov_data,
        )
        stats["stock_movements"] = len(mov_data)

        # ---------- 12. restock_requests (+300) ----------
        req_data = []
        for _ in range(300):
            req_data.append((
                random.choice(all_ing_ids),
                round(random.uniform(5, 50), 2),
                _weighted([("new", 40), ("approved", 25),
                           ("done", 25), ("rejected", 10)]),
                random.choice(keeper_ids),
                _rand_dt(days),
            ))
        db.executemany(
            "INSERT INTO restock_requests (ingredient_id, qty, status, "
            "created_by, created_at) VALUES (?, ?, ?, ?, ?)",
            req_data,
        )
        stats["restock_requests"] = len(req_data)

        # ---------- 13. audit_log (+2000) ----------
        all_user_ids = [r["id"] for r in
                        db.execute("SELECT id FROM users").fetchall()]
        actions = [
            "Вход в систему", "Выход из системы",
            "Просмотр финансовой панели", "Открыт заказ",
            "Заказ отправлен на кухню", "Заказ оплачен и закрыт",
            "Изменён статус пользователя", "Просмотр отчёта",
            "Складская операция", "Принят сотрудник",
            "Добавлено блюдо", "Обновлена техкарта",
            "Просмотр журнала аудита", "SQL-консоль",
        ]
        audit_data = []
        for _ in range(2000):
            audit_data.append((
                random.choice(all_user_ids),
                random.choice(actions),
                random.choice(["order", "user", "ingredient", "report",
                               "dish", "employee", None]),
                random.randint(1, 1500),
                f"192.168.{random.randint(0, 20)}.{random.randint(2, 250)}",
                _rand_dt(days),
            ))
        db.executemany(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id, "
            "ip, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            audit_data,
        )
        stats["audit_log"] = len(audit_data)

        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    return stats


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def register_seed_load_cli(app):
    @app.cli.command("seed-load")
    @click.option("--orders", "n_orders", default=1500, show_default=True,
                  type=int, help="Сколько заказов сгенерировать.")
    @click.option("--days", default=90, show_default=True, type=int,
                  help="Разброс дат заказов (в днях назад).")
    @click.option("--seed", default=42, show_default=True, type=int,
                  help="Seed для воспроизводимости.")
    def seed_load_command(n_orders, days, seed):
        """Сгенерировать ~12 000 записей во все рабочие таблицы."""
        random.seed(seed)
        try:
            stats = _seed_load(n_orders=n_orders, days=days)
        except Exception as e:
            click.echo(f"Ошибка при генерации: {e}", err=True)
            raise

        click.echo("Сгенерировано:")
        total = 0
        for table, n in stats.items():
            click.echo(f"  {table:22s} +{n}")
            total += n
        click.echo(f"  {'ИТОГО':22s}  {total} строк.")
        click.echo()
        click.echo(f"Пароль всех load_*-пользователей: {_LOAD_PASSWORD}")


def register_link_cli(app):
    @app.cli.command("link-employees")
    def link_employees_command():
        """Привязать существующих пользователей load_* к сотрудникам без user_id."""
        db = get_db()
        db.execute("BEGIN IMMEDIATE")
        try:
            free_users = db.execute(
                "SELECT id, full_name FROM users "
                "WHERE username LIKE 'load_%' AND id NOT IN "
                "(SELECT COALESCE(user_id, 0) FROM employees WHERE user_id IS NOT NULL) "
                "ORDER BY id"
            ).fetchall()

            free_emps = db.execute(
                "SELECT id, full_name FROM employees "
                "WHERE user_id IS NULL AND is_active = 1 "
                "ORDER BY id"
            ).fetchall()

            n = 0
            for emp, usr in zip(free_emps, free_users):
                db.execute("UPDATE employees SET user_id = ? WHERE id = ?",
                           (usr["id"], emp["id"]))
                # Переименуем сотрудника, чтобы ФИО совпадало с логином
                db.execute("UPDATE employees SET full_name = ? WHERE id = ?",
                           (usr["full_name"], emp["id"]))
                n += 1
            db.execute("COMMIT")
        except Exception:
            db.execute("ROLLBACK")
            raise

        click.echo(f"Привязано {n} сотрудников к учётным записям.")