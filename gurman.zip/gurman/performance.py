"""Учёт времени отклика HTTP-маршрутов.

При каждом запросе (кроме static/healthz/самой страницы статистики)
пишем один UPSERT в таблицу `route_stats`:

    calls        — сколько раз вызван endpoint;
    total_ms     — сумма времени (для среднего);
    min_ms/max_ms — экстремумы;
    last_ms      — длительность последнего вызова;
    last_status  — HTTP-статус последнего ответа;
    errors       — счётчик 5xx.

Почему SQLite, а не in-memory dict:
    При `gunicorn -w N` каждый воркер имеет собственный процесс и
    собственный словарь — показания были бы неполными. БД даёт
    агрегированную картину по всем воркерам.

Почему один UPSERT на запрос — это нормально:
    WAL + PK-индекс, запись одной строки — доли миллисекунды.
    Для ресторанной нагрузки (десятки rps) это исчезающе мало.
"""
import time

from flask import g, request

from db import get_db


# Сам себя не считаем (иначе счётчик «calls» на этой странице
# растёт от каждого её просмотра), а также пропускаем служебные.
_SKIP_ENDPOINTS = frozenset({
    "static",
    "healthz",
    "admin.db_performance",
})


def register_performance(app):
    @app.before_request
    def _perf_start():
        g._perf_start = time.perf_counter()

    @app.after_request
    def _perf_record(response):
        start = getattr(g, "_perf_start", None)
        if start is None:
            return response

        endpoint = request.endpoint
        if not endpoint or endpoint in _SKIP_ENDPOINTS:
            return response

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        rule = request.url_rule.rule if request.url_rule else "—"

        try:
            db = get_db()
            db.execute(
                """
                INSERT INTO route_stats
                    (endpoint, method, rule, calls, total_ms,
                     min_ms, max_ms, last_ms, last_status,
                     last_called_at, errors, updated_at)
                VALUES
                    (?, ?, ?, 1, ?, ?, ?, ?, ?,
                     datetime('now'), ?, datetime('now'))
                ON CONFLICT(endpoint) DO UPDATE SET
                    calls          = calls + 1,
                    total_ms       = total_ms + excluded.total_ms,
                    min_ms         = MIN(min_ms, excluded.min_ms),
                    max_ms         = MAX(max_ms, excluded.max_ms),
                    last_ms        = excluded.last_ms,
                    last_status    = excluded.last_status,
                    last_called_at = excluded.last_called_at,
                    errors         = errors + excluded.errors,
                    updated_at     = excluded.updated_at
                """,
                (
                    endpoint,
                    request.method,
                    rule,
                    elapsed_ms,
                    elapsed_ms,
                    elapsed_ms,
                    elapsed_ms,
                    response.status_code,
                    1 if response.status_code >= 500 else 0,
                ),
            )
        except Exception:
            # Никогда не ломаем основной ответ из-за метрики.
            app.logger.exception("Не удалось записать route_stats")
        return response