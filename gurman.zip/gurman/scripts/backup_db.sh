#!/usr/bin/env bash
# Ежедневный бэкап restaurant.db через SQLite VACUUM INTO (безопасно при
# работающих воркерах — читает согласованный снимок, не блокирует запись).
set -euo pipefail

DB_PATH="${GURMAN_DB:-/var/www/gurman/restaurant.db}"
BACKUP_DIR="${GURMAN_BACKUP_DIR:-/var/backups/gurman}"
KEEP_DAYS="${GURMAN_BACKUP_KEEP_DAYS:-30}"
TS="$(date -u +%Y%m%dT%H%M%SZ)"

mkdir -p "$BACKUP_DIR"
OUT="$BACKUP_DIR/restaurant-${TS}.db"

sqlite3 "file:${DB_PATH}?mode=ro" "VACUUM INTO '${OUT}'"
chmod 600 "$OUT"

# Ротация: оставить только свежие
find "$BACKUP_DIR" -name 'restaurant-*.db' -type f -mtime "+${KEEP_DAYS}" -delete

echo "Backup OK: ${OUT}"