"""Управление заказами.

Содержит:
  * открытие / закрытие заказа (open, pay, cancel);
  * работу с позициями (add_item, remove_item, update_item_status);
  * отправку на кухню с автоматическим списанием склада (send_to_kitchen);
  * экран кухни/бара (kitchen_view).

Складские операции делегируются в services.stock — единая точка
изменения остатков (см. ARCHITECTURE.md → Services-слой).
"""
from flask import (
    Blueprint, current_app, flash, g, redirect, render_template,
    request, url_for,
)

from config import (
    ROLE_ADMIN, ROLE_BARTENDER, ROLE_COOK, ROLE_WAITER,
)
from db import get_db
from services.stock import (
    calc_order_needs, check_availability,
    restore_for_cancelled_order, write_off_for_order,
)
from utils import (
    log_action, money, roles_required, safe_int, verify_admin_password,
)


orders = Blueprint("orders", __name__, url_prefix="/orders")


# ---------------------------------------------------------------------------
# Ownership
# ---------------------------------------------------------------------------
def _owns_order(order, user) -> bool:
    """True, если user вправе работать с заказом.

    admin — всегда; waiter — только свой (waiter_id == user.id).
    Остальные роли к заказам не допускаются.
    """
    if user["role"] == ROLE_ADMIN:
        return True
    if user["role"] == ROLE_WAITER:
        return order["waiter_id"] == user["id"]
    return False


def _forbid_foreign_order(order, user):
    """Если заказ чужой — вернуть redirect-ответ. Иначе None."""
    if _owns_order(order, user):
        return None
    flash("Этот заказ принадлежит другому официанту.", "error")
    return redirect(url_for("orders.tables"))


# ---------------------------------------------------------------------------
# Схема зала
# ---------------------------------------------------------------------------
@orders.route("/")
@roles_required(ROLE_WAITER)
def tables():
    db = get_db()
    rows = db.execute(
        """
        SELECT t.*, o.id AS order_id
        FROM restaurant_tables t
        LEFT JOIN orders o
            ON o.table_id = t.id
           AND o.status IN ('open', 'sent', 'served')
        ORDER BY t.number
        """
    ).fetchall()
    return render_template("orders/tables.html", tables=rows)


@orders.route("/table/<int:table_id>/open", methods=("POST",))
@roles_required(ROLE_WAITER)
def open_order(table_id):
    db = get_db()
    table = db.execute("SELECT * FROM restaurant_tables WHERE id = ?",
                       (table_id,)).fetchone()
    if not table:
        flash("Стол не найден.", "error")
        return redirect(url_for("orders.tables"))
    if table["status"] == "reserved":
        flash("Стол забронирован. Сначала снимите бронь.", "error")
        return redirect(url_for("orders.tables"))

    guests = safe_int(request.form.get("guests"), min_=1, max_=50, default=1)

    db.execute("BEGIN IMMEDIATE")
    try:
        existing = db.execute(
            "SELECT id FROM orders WHERE table_id = ? "
            "AND status IN ('open', 'sent', 'served')",
            (table_id,),
        ).fetchone()
        if existing:
            db.execute("ROLLBACK")
            return redirect(url_for("orders.detail", order_id=existing["id"]))

        cur = db.execute(
            "INSERT INTO orders (table_id, waiter_id, guests) "
            "VALUES (?, ?, ?)",
            (table_id, g.user["id"], guests),
        )
        db.execute(
            "UPDATE restaurant_tables SET status = 'occupied' WHERE id = ?",
            (table_id,),
        )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Открыт заказ #{cur.lastrowid} на столе #{table_id}",
               entity_type="order", entity_id=cur.lastrowid)
    return redirect(url_for("orders.detail", order_id=cur.lastrowid))


# ---------------------------------------------------------------------------
# Детали заказа
# ---------------------------------------------------------------------------
@orders.route("/<int:order_id>")
@roles_required(ROLE_WAITER)
def detail(order_id):
    db = get_db()
    order = db.execute(
        """
        SELECT o.*, t.number AS table_number, u.full_name AS waiter_name
        FROM orders o
        LEFT JOIN restaurant_tables t ON t.id = o.table_id
        LEFT JOIN users u ON u.id = o.waiter_id
        WHERE o.id = ?
        """,
        (order_id,),
    ).fetchone()
    if order is None:
        flash("Заказ не найден.", "error")
        return redirect(url_for("orders.tables"))

    resp = _forbid_foreign_order(order, g.user)
    if resp is not None:
        return resp

    items = db.execute(
        """
        SELECT oi.*, d.name AS dish_name, d.station
        FROM order_items oi
        JOIN dishes d ON d.id = oi.dish_id
        WHERE oi.order_id = ?
        ORDER BY oi.id
        """,
        (order_id,),
    ).fetchall()

    dishes = db.execute(
        "SELECT d.*, c.name AS category_name FROM dishes d "
        "LEFT JOIN categories c ON c.id = d.category_id "
        "WHERE d.is_active = 1 ORDER BY c.name, d.name"
    ).fetchall()

    total = money(sum(
        i["price"] * i["qty"] for i in items if i["status"] != "cancelled"
    ))

    return render_template("orders/order_detail.html",
                           order=order, items=items, dishes=dishes, total=total)


# ---------------------------------------------------------------------------
# Позиции
# ---------------------------------------------------------------------------
@orders.route("/<int:order_id>/add_item", methods=("POST",))
@roles_required(ROLE_WAITER)
def add_item(order_id):
    """Добавить блюдо в заказ.

    FIX C-1: SELECT заказа + SELECT блюда + INSERT — атомарно.
    Раньше был race: параллельный send_to_kitchen мог перевести заказ
    в 'sent' между проверкой и INSERT, и позиция попадала в уже
    отправленный заказ.
    """
    db = get_db()
    dish_id = request.form.get("dish_id", type=int)
    qty = safe_int(request.form.get("qty"), min_=1, max_=99, default=1)
    comment = (request.form.get("comment") or "").strip()[:200]

    db.execute("BEGIN IMMEDIATE")
    try:
        order = db.execute("SELECT * FROM orders WHERE id = ?",
                           (order_id,)).fetchone()
        if not order or order["status"] != "open":
            db.execute("ROLLBACK")
            flash("Заказ не найден или уже отправлен/закрыт.", "error")
            return redirect(url_for("orders.tables"))

        if not _owns_order(order, g.user):
            db.execute("ROLLBACK")
            flash("Нельзя менять чужой заказ.", "error")
            return redirect(url_for("orders.tables"))

        dish = db.execute(
            "SELECT * FROM dishes WHERE id = ? AND is_active = 1",
            (dish_id,),
        ).fetchone()
        if not dish:
            db.execute("ROLLBACK")
            flash("Блюдо не найдено.", "error")
            return redirect(url_for("orders.detail", order_id=order_id))

        price = money(dish["price"])
        db.execute(
            "INSERT INTO order_items (order_id, dish_id, qty, price, comment) "
            "VALUES (?, ?, ?, ?, ?)",
            (order_id, dish_id, qty, price, comment or None),
        )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"В заказ #{order_id} добавлено блюдо «{dish['name']}» x{qty}",
               entity_type="order", entity_id=order_id)
    return redirect(url_for("orders.detail", order_id=order_id))


@orders.route("/item/<int:item_id>/remove", methods=("POST",))
@roles_required(ROLE_WAITER)
def remove_item(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM order_items WHERE id = ?",
                      (item_id,)).fetchone()
    if not item:
        flash("Позиция не найдена.", "error")
        return redirect(url_for("orders.tables"))

    order = db.execute("SELECT * FROM orders WHERE id = ?",
                       (item["order_id"],)).fetchone()
    if not order or order["status"] != "open" or item["status"] != "new":
        flash("Удалить можно только новую позицию из открытого заказа.",
              "error")
        return redirect(url_for("orders.detail", order_id=item["order_id"]))

    resp = _forbid_foreign_order(order, g.user)
    if resp is not None:
        return resp

    db.execute("UPDATE order_items SET status = 'cancelled' WHERE id = ?",
               (item_id,))
    log_action(f"Отменена позиция #{item_id} в заказе #{item['order_id']}",
               entity_type="order_item", entity_id=item_id)
    return redirect(url_for("orders.detail", order_id=item["order_id"]))


# ---------------------------------------------------------------------------
# Отправка на кухню
# ---------------------------------------------------------------------------

@orders.route("/<int:order_id>/send", methods=("POST",))
@roles_required(ROLE_WAITER)
def send_to_kitchen(order_id):
    """Передать новые позиции на кухню/бар + списать ингредиенты.

    I-2: логика списания делегирована в services.stock.write_off_for_order.
    """
    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    try:
        order = db.execute("SELECT * FROM orders WHERE id = ?",
                           (order_id,)).fetchone()
        if not order or order["status"] != "open":
            db.execute("ROLLBACK")
            flash("Заказ не найден или уже отправлен.", "error")
            return redirect(url_for("orders.tables"))

        if not _owns_order(order, g.user):
            db.execute("ROLLBACK")
            flash("Нельзя менять чужой заказ.", "error")
            return redirect(url_for("orders.tables"))

        items = db.execute(
            "SELECT * FROM order_items WHERE order_id = ? AND status = 'new'",
            (order_id,),
        ).fetchall()
        if not items:
            db.execute("ROLLBACK")
            flash("Нет новых позиций для отправки.", "warning")
            return redirect(url_for("orders.detail", order_id=order_id))

        # Считаем потребности и проверяем остатки — всё в сервис-слое.
        needs = calc_order_needs(items)
        if not needs:
            db.execute("ROLLBACK")
            flash("У блюд не заполнены техкарты.", "error")
            return redirect(url_for("orders.detail", order_id=order_id))

        shortages = check_availability(needs)
        if shortages:
            db.execute("ROLLBACK")
            for name, need, have, unit in shortages:
                flash(
                    f"Недостаточно «{name}»: нужно {need:.3f} {unit}, "
                    f"есть {have:.3f} {unit}.",
                    "error",
                )
            return redirect(url_for("orders.detail", order_id=order_id))

        # Переводим позиции в cooking и списываем склад.
        for item in items:
            db.execute(
                "UPDATE order_items SET status = 'cooking' WHERE id = ?",
                (item["id"],),
            )
        write_off_for_order(order_id, items, g.user["id"])

        db.execute(
            "UPDATE orders SET status = 'sent', "
            "updated_at = datetime('now') WHERE id = ?",
            (order_id,),
        )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Заказ #{order_id} отправлен на кухню/бар",
               entity_type="order", entity_id=order_id)

    try:
        from telegram_bot import notify_roles
        db2 = get_db()
        order_label = f"Заказ #{order_id}"
        if order["table_id"]:
            t = db2.execute(
                "SELECT number FROM restaurant_tables WHERE id = ?",
                (order["table_id"],)).fetchone()
            if t:
                order_label += f" · стол {t['number']}"

        rows = db2.execute(
            f"SELECT oi.qty, d.name, d.station FROM order_items oi "
            f"JOIN dishes d ON d.id = oi.dish_id "
            f"WHERE oi.id IN ({','.join('?' * len(items))})",
            [i["id"] for i in items],
        ).fetchall()

        for station, roles, icon in (
                ("kitchen", ["cook", "admin"], "🍳"),
                ("bar", ["bartender", "admin"], "🍸"),
        ):
            st_items = [r for r in rows if r["station"] == station]
            if not st_items:
                continue
            body = "\n".join(f"• {r['qty']}× {r['name']}" for r in st_items)
            notify_roles(roles,
                         f"<b>{icon} Новый заказ</b>\n{order_label}\n{body}")
    except Exception:
        current_app.logger.exception("Telegram notify failed")

    return redirect(url_for("orders.detail", order_id=order_id))





@orders.route("/item/<int:item_id>/status", methods=("POST",))
@roles_required(ROLE_COOK, ROLE_BARTENDER, ROLE_WAITER)
def update_item_status(item_id):
    db = get_db()
    new_status = request.form.get("status")
    item = db.execute(
        """
        SELECT oi.*, d.station, o.status AS order_status, o.waiter_id
        FROM order_items oi
        JOIN dishes d ON d.id = oi.dish_id
        JOIN orders o ON o.id = oi.order_id
        WHERE oi.id = ?
        """,
        (item_id,),
    ).fetchone()
    if not item:
        flash("Позиция не найдена.", "error")
        return redirect(url_for("orders.tables"))

    role = g.user["role"]
    ok = False
    if role in (ROLE_COOK, ROLE_BARTENDER):
        expected_station = "bar" if role == ROLE_BARTENDER else "kitchen"
        if (item["station"] == expected_station
                and item["status"] == "cooking"
                and new_status == "ready"):
            ok = True
    elif role == ROLE_WAITER:
        if (item["waiter_id"] == g.user["id"]
                and item["status"] == "ready"
                and new_status == "served"):
            ok = True
    elif role == ROLE_ADMIN:
        allowed = {
            "cooking": {"ready", "cancelled"},
            "ready":   {"served", "cancelled"},
            "new":     {"cancelled"},
        }
        if new_status in allowed.get(item["status"], set()):
            ok = True

    if not ok:
        flash("Недопустимый переход статуса.", "error")
        return redirect(url_for("orders.tables"))

    db.execute("UPDATE order_items SET status = ? WHERE id = ?",
               (new_status, item_id))
    log_action(f"Позиция #{item_id} → {new_status}",
               entity_type="order_item", entity_id=item_id)
    # --- Telegram: если блюдо готово — уведомить официанта ---
    if new_status == "ready" and item["waiter_id"]:
        try:
            from telegram_bot import notify_user
            notify_user(
                item["waiter_id"],
                f"<b>✅ Готово к подаче</b>\n"
                f"Заказ #{item['order_id']} · {_dish_name(item)} × {item['qty']}"
            )
        except Exception:
            current_app.logger.exception("Telegram notify (ready) failed")
    return redirect(url_for("orders.detail", order_id=item["order_id"]))


# ---------------------------------------------------------------------------
# Оплата и отмена
# ---------------------------------------------------------------------------
@orders.route("/<int:order_id>/pay", methods=("POST",))
@roles_required(ROLE_WAITER)
def pay(order_id):
    """Оплатить и закрыть заказ.

    FIX C-3: re-auth. Оплата меняет финансы и закрывает стол — при
    угоне сессии без пароля это невозможно.
    """
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?",
                       (order_id,)).fetchone()
    if not order:
        flash("Заказ не найден.", "error")
        return redirect(url_for("orders.tables"))

    if order["status"] not in ("sent", "served"):
        flash("Оплатить можно только заказ в статусе «На кухне» "
              "или «Подан».", "error")
        return redirect(url_for("orders.detail", order_id=order_id))

    resp = _forbid_foreign_order(order, g.user)
    if resp is not None:
        return resp

    # --- re-auth (C-3) ---
    admin_password = request.form.get("admin_password") or ""
    if not admin_password:
        flash("Введите пароль для подтверждения оплаты.", "error")
        return redirect(url_for("orders.detail", order_id=order_id))
    if not verify_admin_password(db, g.user["id"], admin_password):
        log_action("Re-auth провал при оплате заказа",
                   entity_type="order", entity_id=order_id)
        flash("Неверный пароль. Оплата отклонена.", "error")
        return redirect(url_for("orders.detail", order_id=order_id))

    # Не даём закрыть заказ, пока есть позиции не в статусе served/cancelled.
    pending = db.execute(
        "SELECT COUNT(*) AS c FROM order_items "
        "WHERE order_id = ? AND status NOT IN ('served', 'cancelled')",
        (order_id,),
    ).fetchone()["c"]
    if pending:
        flash(
            f"Нельзя закрыть заказ: {pending} позиц. ещё не поданы. "
            "Отметьте их как «Подано» или отмените.",
            "error",
        )
        return redirect(url_for("orders.detail", order_id=order_id))

    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "UPDATE orders SET status = 'paid', "
            "closed_at = datetime('now'), "
            "updated_at = datetime('now') WHERE id = ?",
            (order_id,),
        )
        if order["table_id"]:
            db.execute(
                "UPDATE restaurant_tables SET status = 'free' WHERE id = ?",
                (order["table_id"],),
            )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Заказ #{order_id} оплачен и закрыт",
               entity_type="order", entity_id=order_id)
    flash("Заказ оплачен и закрыт.", "success")
    return redirect(url_for("orders.tables"))


@orders.route("/<int:order_id>/cancel", methods=("POST",))
@roles_required(ROLE_WAITER)
def cancel(order_id):
    """Отменить заказ с возвратом склада.

    FIX C-3: re-auth.
    I-2: возврат склада делегирован в services.stock.
    """
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?",
                       (order_id,)).fetchone()
    if not order:
        flash("Заказ не найден.", "error")
        return redirect(url_for("orders.tables"))
    if order["status"] in ("paid", "cancelled"):
        flash("Заказ уже закрыт.", "error")
        return redirect(url_for("orders.detail", order_id=order_id))

    resp = _forbid_foreign_order(order, g.user)
    if resp is not None:
        return resp

    # --- re-auth (C-3) ---
    admin_password = request.form.get("admin_password") or ""
    if not admin_password:
        flash("Введите пароль для подтверждения отмены.", "error")
        return redirect(url_for("orders.detail", order_id=order_id))
    if not verify_admin_password(db, g.user["id"], admin_password):
        log_action("Re-auth провал при отмене заказа",
                   entity_type="order", entity_id=order_id)
        flash("Неверный пароль. Отмена отклонена.", "error")
        return redirect(url_for("orders.detail", order_id=order_id))

    db.execute("BEGIN IMMEDIATE")
    try:
        sent_items = db.execute(
            "SELECT id, dish_id, qty FROM order_items "
            "WHERE order_id = ? AND status IN ('cooking', 'ready')",
            (order_id,),
        ).fetchall()

        if sent_items:
            restore_for_cancelled_order(order_id, sent_items, g.user["id"])

        db.execute(
            "UPDATE orders SET status = 'cancelled', "
            "closed_at = datetime('now'), "
            "updated_at = datetime('now') WHERE id = ?",
            (order_id,),
        )
        db.execute(
            "UPDATE order_items SET status = 'cancelled' "
            "WHERE order_id = ? AND status NOT IN ('served', 'cancelled')",
            (order_id,),
        )
        if order["table_id"]:
            db.execute(
                "UPDATE restaurant_tables SET status = 'free' WHERE id = ?",
                (order["table_id"],),
            )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Заказ #{order_id} отменён",
               entity_type="order", entity_id=order_id)
    flash("Заказ отменён.", "success")
    return redirect(url_for("orders.tables"))


# ---------------------------------------------------------------------------
# Экран кухни / бара
# ---------------------------------------------------------------------------
@orders.route("/kitchen")
@roles_required(ROLE_COOK, ROLE_BARTENDER)
def kitchen_view():
    db = get_db()
    station = "bar" if g.user["role"] == ROLE_BARTENDER else "kitchen"
    items = db.execute(
        """
        SELECT oi.*, d.name AS dish_name, o.id AS order_id,
               t.number AS table_number
        FROM order_items oi
        JOIN dishes d ON d.id = oi.dish_id
        JOIN orders o ON o.id = oi.order_id
        LEFT JOIN restaurant_tables t ON t.id = o.table_id
        WHERE d.station = ? AND oi.status IN ('cooking', 'ready')
        ORDER BY oi.id
        """,
        (station,),
    ).fetchall()
    return render_template("orders/kitchen.html", items=items, station=station)