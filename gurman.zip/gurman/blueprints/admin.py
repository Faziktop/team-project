"""Админ-модуль: просмотр БД и SQL-консоль (только SELECT)."""
import re
import sqlite3
import time

from flask import (
    Blueprint, current_app, flash, redirect, render_template, request, url_for,
)

from config import Config, ROLE_ADMIN, _IDENT_RE
from db import get_db
from utils import log_action, roles_required, safe_int
from flask import current_app, g, send_file

admin = Blueprint("admin", __name__, url_prefix="/admin")


_FORBIDDEN_SQL_KEYWORDS = (
    "insert", "update", "delete", "drop", "alter", "create",
    "replace", "attach", "detach", "pragma", "vacuum",
    "reindex", "grant", "revoke", "begin", "commit", "rollback",
    "savepoint", "release", "truncate", "load_extension",
)


# Разрешённые "глаголы" для write-режима (первое слово запроса).
_WRITE_VERBS = ("insert", "update", "delete", "drop", "alter")

# Категорически запрещены в любом режиме — ломают БД или открывают RCE.
_ALWAYS_FORBIDDEN = (
    "attach", "detach", "pragma", "vacuum", "reindex",
    "load_extension", "grant", "revoke",
)


def _strip_sql(sql: str) -> str:
    """Убрать комментарии и завершающую ;."""
    cleaned = re.sub(r"--[^\n]*", " ", sql)
    cleaned = re.sub(r"/\*.*?\*/", " ", cleaned, flags=re.DOTALL)
    return cleaned.strip().rstrip(";").strip()


def _has_forbidden(sql_lower: str) -> str | None:
    for kw in _ALWAYS_FORBIDDEN:
        if re.search(rf"\b{re.escape(kw)}\b", sql_lower):
            return kw
    return None


def _is_select_only(sql: str) -> tuple[bool, str | None]:
    """Только SELECT/WITH. Используется в read-режиме."""
    if not sql or not sql.strip():
        return False, "Пустой запрос."
    if len(sql) > 5000:
        return False, "Запрос слишком длинный (максимум 5000 символов)."

    cleaned = _strip_sql(sql)
    if not re.match(r"^\s*(select|with)\b", cleaned, flags=re.IGNORECASE):
        return False, "Разрешены только SELECT/WITH-запросы."
    if ";" in cleaned:
        return False, "Множественные запросы в одном вызове запрещены."

    bad = _has_forbidden(cleaned.lower())
    if bad:
        return False, f"Запрещённое ключевое слово: {bad}."
    return True, None


def _is_safe_write(sql: str) -> tuple[bool, str | None]:
    """INSERT/UPDATE/DELETE/DROP/ALTER — для write-режима.

    Всё равно блокируем ATTACH/PRAGMA/LOAD_EXTENSION и т.п.
    Разрешаем только ОДИН запрос за раз.
    """
    if not sql or not sql.strip():
        return False, "Пустой запрос."
    if len(sql) > 5000:
        return False, "Запрос слишком длинный (максимум 5000 символов)."

    cleaned = _strip_sql(sql)
    low = cleaned.lower()

    first = low.split(None, 1)[0] if low.split() else ""
    if first not in _WRITE_VERBS and not low.startswith("with"):
        # WITH ... DELETE/UPDATE тоже бывает, но простому пользователю
        # не нужно — оставим только явные глаголы.
        return False, (
            "В режиме записи разрешены только INSERT, UPDATE, DELETE, "
            "DROP, ALTER."
        )
    if ";" in cleaned:
        return False, "Множественные запросы в одном вызове запрещены."

    bad = _has_forbidden(low)
    if bad:
        return False, f"Запрещённое ключевое слово: {bad}."

    return True, None


def _open_connection(*, readonly: bool) -> sqlite3.Connection:
    """Открыть соединение без URI-режима.

    Почему не f"file:...?mode=ro": путь к БД — сетевая шара с
    кириллицей, пробелами и обратными слэшами. SQLite URI-парсер
    такой путь не принимает. Открываем обычным путём, а запись
    блокируем через PRAGMA query_only = ON.
    """
    conn = sqlite3.connect(
        Config.DATABASE,      # обычный путь, без URI
        timeout=5.0,
        isolation_level=None, # autocommit — коммитим каждую операцию
    )
    conn.row_factory = sqlite3.Row

    if readonly:
        conn.execute("PRAGMA query_only = ON")

    # Soft-timeout 3 с.
    deadline = time.monotonic() + 3.0

    def _abort_if_too_long():
        return 1 if time.monotonic() > deadline else 0

    conn.set_progress_handler(_abort_if_too_long, 10000)
    return conn


def _readonly_connection() -> sqlite3.Connection:
    return _open_connection(readonly=True)


def _rw_connection() -> sqlite3.Connection:
    return _open_connection(readonly=False)

@admin.route("/db")
@roles_required(ROLE_ADMIN)
def db_tables():
    db = get_db()
    rows = db.execute(
        "SELECT name FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    tables = []
    for r in rows:
        name = r["name"]
        if not _IDENT_RE.fullmatch(name):
            continue
        try:
            cnt = db.execute(
                f'SELECT COUNT(*) AS c FROM "{name}"'
            ).fetchone()["c"]
        except sqlite3.Error:
            cnt = 0
        tables.append({"name": name, "count": cnt})
    return render_template("admin/db_tables.html", tables=tables)


@admin.route("/db/view/<table>")
@roles_required(ROLE_ADMIN)
def db_view(table):
    if not _IDENT_RE.fullmatch(table):
        flash("Недопустимое имя таблицы.", "error")
        return redirect(url_for("admin.db_tables"))
    db = get_db()
    exists = db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?",
        (table,),
    ).fetchone()
    if not exists:
        flash("Таблица не найдена.", "error")
        return redirect(url_for("admin.db_tables"))

    page = safe_int(request.args.get("page"), min_=1, max_=100000, default=1) or 1
    per_page = 50
    offset = (page - 1) * per_page
    columns = db.execute(f'PRAGMA table_info("{table}")').fetchall()
    total = db.execute(f'SELECT COUNT(*) AS c FROM "{table}"').fetchone()["c"]
    rows = db.execute(
        f'SELECT * FROM "{table}" LIMIT ? OFFSET ?',
        (per_page, offset),
    ).fetchall()
    return render_template(
        "admin/db_view.html",
        table=table, columns=columns, rows=rows,
        page=page, per_page=per_page, total=total,
        pages=max(1, (total + per_page - 1) // per_page),
    )


@admin.route("/db/query", methods=("GET", "POST"))
@roles_required(ROLE_ADMIN)
def db_query():
    sql = ""
    columns = None
    rows = None
    error = None
    info = None           # текст успеха для write-режима
    mode = "read"         # по умолчанию — только SELECT
    write_ok = False      # подтверждение паролем получено

    if request.method == "POST":
        sql = (request.form.get("sql") or "").strip()
        mode = "write" if request.form.get("allow_write") else "read"

        # ---- write-режим требует подтверждения паролем ----
        if mode == "write":
            pwd = request.form.get("admin_password") or ""
            from werkzeug.security import check_password_hash
            row = get_db().execute(
                "SELECT password_hash FROM users WHERE id = ?",
                (g.user["id"],),
            ).fetchone()
            if not pwd or not row or not check_password_hash(
                    row["password_hash"], pwd):
                log_action("Re-auth провал при SQL-write",
                           entity_type="db_query")
                error = ("Неверный пароль администратора. "
                         "Операция записи отклонена.")
                return render_template(
                    "admin/db_query.html",
                    sql=sql, columns=None, rows=None,
                    error=error, info=None, mode=mode,
                )

        # ---- валидация SQL ----
        if mode == "write":
            ok, err = _is_safe_write(sql)
        else:
            ok, err = _is_select_only(sql)

        if not ok:
            error = err
        else:
            conn = None
            try:
                conn = _rw_connection() if mode == "write" else _readonly_connection()

                cur = conn.execute(sql)

                # Для SELECT — забрать строки. Для DML/DDL — cur.description пуст.
                if cur.description is not None:
                    columns = [d[0] for d in cur.description]
                    rows = cur.fetchmany(500)
                    log_action(
                        f"SQL-консоль ({mode}): {sql[:200]}",
                        entity_type="db_query",
                    )
                else:
                    # DML/DDL: сообщим, сколько строк затронуто.
                    affected = conn.total_changes
                    info = f"Запрос выполнен. Затронуто строк: {affected}."
                    log_action(
                        f"SQL-консоль ({mode}, DML): {sql[:200]}",
                        entity_type="db_query",
                    )

            except sqlite3.OperationalError as e:
                current_app.logger.exception("SQL-консоль: ошибка выполнения")
                msg = str(e)
                if "interrupted" in msg.lower():
                    error = "Запрос выполнялся слишком долго и был прерван."
                else:
                    error = f"Ошибка SQL: {msg}"
                columns = None
                rows = None
            except sqlite3.Error as e:
                current_app.logger.exception("SQL-консоль: ошибка SQL")
                error = f"Ошибка SQL: {e}"
                columns = None
                rows = None
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass

    return render_template(
        "admin/db_query.html",
        sql=sql, columns=columns, rows=rows,
        error=error, info=info, mode=mode,
    )

@admin.route("/db/performance")
@roles_required(ROLE_ADMIN)
def db_performance():
    """Сводка времени отклика по ВСЕМ маршрутам приложения.

    Источник списка маршрутов — current_app.url_map, поэтому таблица
    заполнена сразу, без единого запроса пользователя. Маршруты,
    которые ещё ни разу не вызывались, показываются с прочерками.
    """
    db = get_db()
    rows = db.execute(
        "SELECT endpoint, method, rule, calls, total_ms, min_ms, max_ms, "
        "       last_ms, last_status, last_called_at, errors "
        "FROM route_stats"
    ).fetchall()
    stats_by_ep = {r["endpoint"]: dict(r) for r in rows}

    stats = []
    seen: set[str] = set()

    for rule in current_app.url_map.iter_rules():
        ep = rule.endpoint
        if ep == "static" or ep in seen:
            continue
        seen.add(ep)

        methods = sorted(
            m for m in (rule.methods or ())
            if m not in ("HEAD", "OPTIONS")
        ) or ["GET"]
        methods_str = ", ".join(methods)

        s = stats_by_ep.get(ep)
        if s is None:
            s = {
                "endpoint":       ep,
                "method":         methods_str,
                "rule":           rule.rule,
                "calls":          0,
                "total_ms":       0.0,
                "min_ms":         0.0,
                "max_ms":         0.0,
                "last_ms":        0.0,
                "last_status":    None,
                "last_called_at": None,
                "errors":         0,
            }
        else:
            s["rule"] = rule.rule
            s["method"] = methods_str
            s["min_ms"] = s.get("min_ms") or 0.0
            s["max_ms"] = s.get("max_ms") or 0.0
            s["last_ms"] = s.get("last_ms") or 0.0

        calls = s["calls"] or 0
        s["avg_ms"] = (s["total_ms"] / calls) if calls else 0.0
        stats.append(s)

    # Сначала вызывавшиеся (по убыванию среднего времени),
    # затем невызывавшиеся — по алфавиту.
    stats.sort(key=lambda x: (
        0 if x["calls"] else 1,
        -x["avg_ms"],
        x["endpoint"],
    ))

    total_ms = sum(s["avg_ms"] * s["calls"] for s in stats)
    called_calls = sum(s["calls"] for s in stats)
    overall_avg = (total_ms / called_calls) if called_calls else 0.0

    return render_template(
        "admin/db_performance.html",
        stats=stats,
        overall_avg=overall_avg,
    )

import re
import shutil
from datetime import datetime
from pathlib import Path

from flask import send_file, current_app


_BACKUP_NAME_RE = re.compile(r"^restaurant-\d{8}T\d{6}Z\.db$")
_MAX_BACKUPS = 30


def _backup_dir() -> Path:
    """Папка для бэкапов: instance/backups/."""
    d = Path(current_app.instance_path) / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _list_backups() -> list[dict]:
    """Список бэкапов, отсортирован — новые сверху."""
    d = _backup_dir()
    items = []
    for f in d.iterdir():
        if not f.is_file() or not _BACKUP_NAME_RE.match(f.name):
            continue
        st = f.stat()
        items.append({
            "name": f.name,
            "size_kb": round(st.st_size / 1024, 1),
            "created": datetime.fromtimestamp(st.st_mtime).strftime(
                "%Y-%m-%d %H:%M:%S"),
            "mtime": st.st_mtime,
        })
    items.sort(key=lambda x: x["mtime"], reverse=True)
    return items


def _prune_backups(keep: int = _MAX_BACKUPS) -> int:
    """Оставить N последних бэкапов, остальные удалить."""
    items = _list_backups()
    removed = 0
    for it in items[keep:]:
        try:
            (_backup_dir() / it["name"]).unlink()
            removed += 1
        except OSError:
            pass
    return removed


def _make_backup() -> Path:
    """Сделать снимок текущей БД через VACUUM INTO."""
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    out = _backup_dir() / f"restaurant-{ts}.db"

    conn = sqlite3.connect(
        f"file:{Config.DATABASE}?mode=ro", uri=True, timeout=30.0,
    )
    try:
        conn.execute(f"VACUUM INTO '{out}'")
    finally:
        conn.close()
    return out


@admin.route("/backups")
@roles_required(ROLE_ADMIN)
def backups_list():
    return render_template(
        "admin/backups.html",
        backups=_list_backups(),
        max_backups=_MAX_BACKUPS,
    )


@admin.route("/backups/create", methods=("POST",))
@roles_required(ROLE_ADMIN)
def backups_create():
    try:
        path = _make_backup()
        removed = _prune_backups()
        log_action(f"Создан бэкап {path.name}", entity_type="backup")
        msg = f"Бэкап создан: {path.name}"
        if removed:
            msg += f" (удалено старых: {removed})"
        flash(msg, "success")
    except Exception:
        current_app.logger.exception("Ошибка создания бэкапа")
        flash("Не удалось создать бэкап. Смотрите лог.", "error")
    return redirect(url_for("admin.backups_list"))


@admin.route("/backups/download/<name>")
@roles_required(ROLE_ADMIN)
def backups_download(name):
    if not _BACKUP_NAME_RE.match(name):
        flash("Недопустимое имя файла.", "error")
        return redirect(url_for("admin.backups_list"))

    path = _backup_dir() / name
    if not path.is_file():
        flash("Файл не найден.", "error")
        return redirect(url_for("admin.backups_list"))

    log_action(f"Скачан бэкап {name}", entity_type="backup")
    return send_file(
        str(path),
        mimetype="application/x-sqlite3",
        as_attachment=True,
        download_name=name,
    )


@admin.route("/backups/delete/<name>", methods=("POST",))
@roles_required(ROLE_ADMIN)
def backups_delete(name):
    if not _BACKUP_NAME_RE.match(name):
        flash("Недопустимое имя файла.", "error")
        return redirect(url_for("admin.backups_list"))

    path = _backup_dir() / name
    if path.is_file():
        try:
            path.unlink()
            log_action(f"Удалён бэкап {name}", entity_type="backup")
            flash(f"Бэкап {name} удалён.", "success")
        except OSError:
            flash("Не удалось удалить файл.", "error")
    return redirect(url_for("admin.backups_list"))


@admin.route("/backups/restore/<name>", methods=("POST",))
@roles_required(ROLE_ADMIN)
def backups_restore(name):
    """Восстановить БД из бэкапа.

    Автоматически делает снимок текущей БД перед заменой, чтобы
    можно было откатиться. Операция требует re-auth.
    """
    from werkzeug.security import check_password_hash

    if not _BACKUP_NAME_RE.match(name):
        flash("Недопустимое имя файла.", "error")
        return redirect(url_for("admin.backups_list"))

    src = _backup_dir() / name
    if not src.is_file():
        flash("Файл не найден.", "error")
        return redirect(url_for("admin.backups_list"))

    # Re-auth
    pwd = request.form.get("admin_password") or ""
    db = get_db()
    row = db.execute("SELECT password_hash FROM users WHERE id = ?",
                     (g.user["id"],)).fetchone()
    if not pwd or not row or not check_password_hash(row["password_hash"], pwd):
        log_action("Re-auth провал при восстановлении БД",
                   entity_type="backup")
        flash("Неверный пароль. Восстановление отклонено.", "error")
        return redirect(url_for("admin.backups_list"))

    # Валидация целостности бэкапа ДО подмены
    try:
        test = sqlite3.connect(f"file:{src}?mode=ro", uri=True, timeout=10.0)
        try:
            res = test.execute("PRAGMA integrity_check").fetchone()
            if not res or res[0] != "ok":
                raise RuntimeError(f"integrity_check: {res}")
            has_users = test.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'"
            ).fetchone()
            if not has_users:
                raise RuntimeError("нет таблицы users")
        finally:
            test.close()
    except Exception as e:
        current_app.logger.exception("Восстановление БД: бэкап невалиден")
        flash(f"Бэкап повреждён или несовместим: {e}", "error")
        return redirect(url_for("admin.backups_list"))

    # Автоснимок текущей БД перед заменой
    try:
        pre = _make_backup()
        log_action(f"Автоснимок перед восстановлением: {pre.name}",
                   entity_type="backup")
    except Exception:
        current_app.logger.exception("Не удалось сделать автоснимок")
        flash("Не удалось сделать страховочный снимок. Отменено.", "error")
        return redirect(url_for("admin.backups_list"))

    # Закрываем все соединения и подменяем файл
    try:
        from db import close_db
        close_db()

        dst = Path(Config.DATABASE)
        # Удаляем WAL/SHM, чтобы не подтянулись старые страницы
        for suffix in ("-wal", "-shm"):
            p = Path(str(dst) + suffix)
            if p.exists():
                p.unlink()

        shutil.copy2(src, dst)

        log_action(f"БД восстановлена из {name}", entity_type="backup")
        flash("База данных восстановлена. Текущая сессия может "
              "потребовать повторного входа.", "success")
    except Exception:
        current_app.logger.exception("Ошибка восстановления БД")
        flash("Ошибка восстановления. Смотрите лог.", "error")

    return redirect(url_for("admin.backups_list"))

import io
import secrets as _secrets

import qrcode
import qrcode.image.svg

from flask import send_file


def _ensure_table_token(table_id: int) -> str:
    """Вернуть существующий или сгенерировать новый токен для стола."""
    db = get_db()
    row = db.execute(
        "SELECT public_token FROM restaurant_tables WHERE id = ?",
        (table_id,),
    ).fetchone()
    if not row:
        raise ValueError("Стол не найден")
    if row["public_token"]:
        return row["public_token"]
    token = _secrets.token_urlsafe(16)
    db.execute(
        "UPDATE restaurant_tables SET public_token = ? WHERE id = ?",
        (token, table_id),
    )
    return token


@admin.route("/qr")
@roles_required(ROLE_ADMIN)
def qr_tables():
    """Список столов с QR-кодами."""
    db = get_db()
    tables = db.execute(
        "SELECT * FROM restaurant_tables ORDER BY number"
    ).fetchall()

    items = []
    for t in tables:
        token = t["public_token"] or _ensure_table_token(t["id"])
        url = url_for("tables_public.table_menu", token=token, _external=True)
        items.append({
            "id": t["id"],
            "number": t["number"],
            "seats": t["seats"],
            "status": t["status"],
            "token": token,
            "url": url,
        })

    return render_template("admin/qr_tables.html", items=items)


@admin.route("/qr/<int:table_id>/svg")
@roles_required(ROLE_ADMIN)
def qr_table_svg(table_id):
    """QR-код стола в SVG.

    Отдаётся inline (не как attachment) — чтобы встраивался
    прямо в <img src="..."> на странице /admin/qr.
    """
    token = _ensure_table_token(table_id)
    url = url_for("tables_public.table_menu", token=token, _external=True)

    img = qrcode.make(
        url,
        image_factory=qrcode.image.svg.SvgPathImage,
        box_size=12,
        border=2,
    )
    buf = io.BytesIO()
    img.save(buf)
    buf.seek(0)

    from flask import Response
    resp = Response(buf.read(), mimetype="image/svg+xml")
    resp.headers["Cache-Control"] = "public, max-age=3600"
    return resp


@admin.route("/qr/<int:table_id>/download")
@roles_required(ROLE_ADMIN)
def qr_table_download(table_id):
    """Скачать SVG-файл QR-кода стола — для печати."""
    token = _ensure_table_token(table_id)
    url = url_for("tables_public.table_menu", token=token, _external=True)

    img = qrcode.make(
        url,
        image_factory=qrcode.image.svg.SvgPathImage,
        box_size=20,
        border=3,
    )
    buf = io.BytesIO()
    img.save(buf)
    buf.seek(0)

    log_action(f"Скачан QR-код стола #{table_id}",
               entity_type="table", entity_id=table_id)

    return send_file(
        buf,
        mimetype="image/svg+xml",
        as_attachment=True,
        download_name=f"gurman-table-{table_id}.svg",
    )


@admin.route("/qr/regenerate/<int:table_id>", methods=("POST",))
@roles_required(ROLE_ADMIN)
def qr_regenerate(table_id):
    """Перегенерировать токен — старый QR перестанет работать."""
    db = get_db()
    new_token = _secrets.token_urlsafe(16)
    db.execute(
        "UPDATE restaurant_tables SET public_token = ? WHERE id = ?",
        (new_token, table_id),
    )
    log_action(f"Перегенерирован QR-токен стола #{table_id}",
               entity_type="table", entity_id=table_id)
    flash("QR-код перегенерирован. Старый больше не действует.", "success")
    return redirect(url_for("admin.qr_tables"))