"""Склад: остатки, движения, заявки.

Использует services.stock как единую точку изменения остатков.
"""
from flask import (
    Blueprint, current_app, flash, g, redirect, render_template,
    request, url_for,
)

from config import ROLE_ACCOUNTANT, ROLE_STOREKEEPER
from config import Config, ROLE_ADMIN, _IDENT_RE
from db import get_db
from services.stock import (
    apply_inventory, apply_receipt, apply_stock_movement, apply_writeoff,
)
from utils import (
    log_action, roles_required, safe_float, verify_admin_password,
)


warehouse = Blueprint("warehouse", __name__, url_prefix="/warehouse")


@warehouse.route("/")
@roles_required(ROLE_STOREKEEPER, ROLE_ACCOUNTANT)
def stock():
    db = get_db()
    ingredients = db.execute(
        "SELECT * FROM ingredients ORDER BY name"
    ).fetchall()
    return render_template("warehouse/stock.html", ingredients=ingredients)


@warehouse.route("/new", methods=("GET", "POST"))
@roles_required(ROLE_STOREKEEPER)
def new_ingredient():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        unit = (request.form.get("unit") or "шт").strip()[:20] or "шт"
        stock_qty = safe_float(request.form.get("stock_qty"),
                               min_=0, max_=1_000_000)
        min_qty = safe_float(request.form.get("min_qty"),
                             min_=0, max_=1_000_000)
        db = get_db()

        if not name:
            flash("Укажите наименование товара.", "error")
        elif len(name) > 200:
            flash("Слишком длинное наименование.", "error")
        elif stock_qty is None or min_qty is None:
            flash("Некорректное количество (0 – 1 000 000).", "error")
        else:
            db.execute(
                "INSERT INTO ingredients (name, unit, stock_qty, min_qty) "
                "VALUES (?, ?, ?, ?)", (name, unit, stock_qty, min_qty),
            )
            log_action(f"Добавлен товар на склад: {name}",
                       entity_type="ingredient")
            flash("Товар добавлен.", "success")
            return redirect(url_for("warehouse.stock"))
    return render_template("warehouse/ingredient_form.html")


@warehouse.route("/<int:ingredient_id>/movement", methods=("POST",))
@roles_required(ROLE_STOREKEEPER)
def movement(ingredient_id):
    """Приход / списание / инвентаризация.

    FIX C-3: re-auth — движение меняет остатки, при угоне сессии
    без пароля это невозможно.

    I-2: вся логика изменения остатков делегирована в services.stock.
    """
    db = get_db()
    reason = request.form.get("reason")
    comment = (request.form.get("comment") or "").strip()[:200]

    if reason not in ("receipt", "writeoff", "inventory"):
        flash("Некорректный тип операции.", "error")
        return redirect(url_for("warehouse.stock"))
    if reason == "inventory" and not comment:
        flash("Для инвентаризации обязателен комментарий с обоснованием.",
              "error")
        return redirect(url_for("warehouse.stock"))

    qty = safe_float(request.form.get("qty"), min_=0, max_=1_000_000)
    if qty is None:
        flash("Введите корректное количество (0 – 1 000 000).", "error")
        return redirect(url_for("warehouse.stock"))
    if reason in ("receipt", "writeoff") and qty <= 0:
        flash("Количество должно быть больше нуля.", "error")
        return redirect(url_for("warehouse.stock"))

    # --- re-auth (C-3) ---
    admin_password = request.form.get("admin_password") or ""
    if not admin_password:
        flash("Введите пароль для подтверждения операции.", "error")
        return redirect(url_for("warehouse.stock"))
    if not verify_admin_password(db, g.user["id"], admin_password):
        log_action("Re-auth провал при складской операции",
                   entity_type="ingredient", entity_id=ingredient_id)
        flash("Неверный пароль. Операция отклонена.", "error")
        return redirect(url_for("warehouse.stock"))

    db.execute("BEGIN IMMEDIATE")
    try:
        ing = db.execute("SELECT * FROM ingredients WHERE id = ?",
                         (ingredient_id,)).fetchone()
        if not ing:
            db.execute("ROLLBACK")
            flash("Товар не найден.", "error")
            return redirect(url_for("warehouse.stock"))

        if reason == "receipt":
            apply_receipt(ingredient_id, qty,
                          comment=comment or None, user_id=g.user["id"])
            log_msg = f"Приход #{ingredient_id}: +{qty:.2f} {ing['unit']}"

        elif reason == "writeoff":
            try:
                apply_writeoff(ingredient_id, qty,
                               comment=comment or None, user_id=g.user["id"])
            except ValueError as e:
                db.execute("ROLLBACK")
                flash(str(e), "error")
                return redirect(url_for("warehouse.stock"))
            log_msg = f"Списание #{ingredient_id}: -{qty:.2f} {ing['unit']}"

        else:  # inventory
            change = apply_inventory(ingredient_id, qty, comment=comment,
                                     user_id=g.user["id"])
            log_msg = (
                f"Инвентаризация #{ingredient_id}: "
                f"было {ing['stock_qty']:.3f}, стало {qty:.3f} "
                f"(изм. {change:+.3f}, {comment})"
            )

        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(log_msg, entity_type="ingredient", entity_id=ingredient_id)
    try:
        from telegram_bot import notify_roles
        row = db.execute(
            "SELECT name, unit, stock_qty, min_qty FROM ingredients "
            "WHERE id = ?", (ingredient_id,)).fetchone()
        if row and row["stock_qty"] <= row["min_qty"]:
            notify_roles(["storekeeper", "admin"],
                f"<b>⚠️ Низкий остаток</b>\n"
                f"«{row['name']}»: {row['stock_qty']:.2f} {row['unit']} "
                f"(мин. {row['min_qty']:.2f} {row['unit']})")
    except Exception:
        current_app.logger.exception("Telegram notify failed")
    return redirect(url_for("warehouse.stock"))


@warehouse.route("/movements")
@roles_required(ROLE_STOREKEEPER, ROLE_ACCOUNTANT)
def movements():
    db = get_db()
    rows = db.execute(
        """
        SELECT sm.*, i.name AS ingredient_name, i.unit, u.full_name AS user_name
        FROM stock_movements sm
        JOIN ingredients i ON i.id = sm.ingredient_id
        LEFT JOIN users u ON u.id = sm.user_id
        ORDER BY sm.created_at DESC, sm.id DESC
        LIMIT 200
        """
    ).fetchall()
    return render_template("warehouse/movements.html", movements=rows)


@warehouse.route("/requests")
@roles_required(ROLE_STOREKEEPER, ROLE_ACCOUNTANT)
def requests_list():
    db = get_db()
    rows = db.execute(
        """
        SELECT r.*, i.name AS ingredient_name, i.unit
        FROM restock_requests r
        JOIN ingredients i ON i.id = r.ingredient_id
        ORDER BY r.status = 'done', r.created_at DESC
        """
    ).fetchall()
    low_stock = db.execute(
        "SELECT * FROM ingredients WHERE stock_qty <= min_qty ORDER BY name"
    ).fetchall()
    return render_template("warehouse/requests.html",
                           requests=rows, low_stock=low_stock)


@warehouse.route("/requests/new", methods=("POST",))
@roles_required(ROLE_STOREKEEPER)
def new_request():
    db = get_db()
    ingredient_id = request.form.get("ingredient_id", type=int)
    qty = safe_float(request.form.get("qty"), min_=0.01, max_=1_000_000)

    if not ingredient_id or qty is None:
        flash("Укажите корректное количество.", "error")
        return redirect(url_for("warehouse.requests_list"))
    ing = db.execute("SELECT id FROM ingredients WHERE id = ?",
                     (ingredient_id,)).fetchone()
    if not ing:
        flash("Товар не найден.", "error")
        return redirect(url_for("warehouse.requests_list"))

    db.execute(
        "INSERT INTO restock_requests (ingredient_id, qty, created_by) "
        "VALUES (?, ?, ?)", (ingredient_id, qty, g.user["id"]),
    )
    log_action(f"Создана заявка на пополнение товара #{ingredient_id}",
               entity_type="restock_request")
    flash("Заявка на пополнение создана.", "success")
    return redirect(url_for("warehouse.requests_list"))


@warehouse.route("/requests/<int:request_id>/status", methods=("POST",))
@roles_required(ROLE_STOREKEEPER, ROLE_ACCOUNTANT)
def update_request_status(request_id):
    """Перевести заявку в новый статус.

    I-2: приход по выполненной заявке идёт через services.stock.
    I-3: проставляем updated_at/closed_at.
    """
    db = get_db()
    new_status = request.form.get("status")
    if new_status not in ("approved", "done", "rejected"):
        flash("Некорректный статус.", "error")
        return redirect(url_for("warehouse.requests_list"))

    db.execute("BEGIN IMMEDIATE")
    try:
        req = db.execute("SELECT * FROM restock_requests WHERE id = ?",
                         (request_id,)).fetchone()
        if not req:
            db.execute("ROLLBACK")
            flash("Заявка не найдена.", "error")
            return redirect(url_for("warehouse.requests_list"))
        if req["status"] in ("done", "rejected"):
            db.execute("ROLLBACK")
            flash("Заявка уже закрыта.", "error")
            return redirect(url_for("warehouse.requests_list"))

        db.execute(
            "UPDATE restock_requests SET status = ?, "
            "updated_at = datetime('now'), "
            "closed_at = CASE WHEN ? IN ('done','rejected') "
            "                 THEN datetime('now') ELSE closed_at END "
            "WHERE id = ?",
            (new_status, new_status, request_id),
        )

        if new_status == "done":
            apply_stock_movement(
                req["ingredient_id"], req["qty"], "receipt",
                comment=f"Заявка #{request_id}", user_id=g.user["id"],
            )

        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Заявка #{request_id} → {new_status}",
               entity_type="restock_request", entity_id=request_id)
    return redirect(url_for("warehouse.requests_list"))

from flask import send_file


@warehouse.route("/export.xlsx")
@roles_required(ROLE_STOREKEEPER, ROLE_ACCOUNTANT)
def export_xlsx():
    """Скачать склад в Excel."""
    from utils import stock_workbook

    db = get_db()
    ingredients = db.execute(
        "SELECT * FROM ingredients ORDER BY name"
    ).fetchall()

    buf = stock_workbook(ingredients)
    log_action("Экспорт склада в Excel", entity_type="ingredient")

    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="gurman-stock.xlsx",
    )