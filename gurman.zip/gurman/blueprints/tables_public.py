"""Быстрый доступ к столу по QR-коду (для сотрудников).

QR на столе ведёт на /t/<token>. Сценарий:
  1. Официант наводит телефон на QR.
  2. Открывается браузер. Если не залогинен — форма входа.
  3. После входа — карточка стола: активный заказ или кнопка
     «Открыть заказ».

Никаких бронирований от гостя, никакого меню — только управление
столом сотрудником.
"""
from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for,
)

from db import get_db


tables_public = Blueprint("tables_public", __name__)


def _table_by_token(token: str):
    if not token or len(token) < 16:
        return None
    db = get_db()
    return db.execute(
        "SELECT * FROM restaurant_tables WHERE public_token = ?",
        (token,),
    ).fetchone()


@tables_public.route("/t/<token>")
def table_menu(token):
    table = _table_by_token(token)
    if not table:
        return render_template("public/table_not_found.html"), 404

    user = getattr(g, "user", None)
    if user is None:
        flash("Это служебный QR-код. Войдите под своей учётной записью.",
              "info")
        return redirect(url_for("auth.login", next=request.path))

    if user["role"] not in ("admin", "waiter"):
        flash("QR-код стола доступен только официантам и администраторам.",
              "error")
        return redirect(url_for("index"))

    db = get_db()
    active_order = db.execute(
        """
        SELECT o.id, o.status, o.guests, o.created_at,
               COALESCE(u.full_name, '—') AS waiter_name,
               (SELECT COALESCE(SUM(oi.qty * oi.price), 0)
                FROM order_items oi
                WHERE oi.order_id = o.id AND oi.status != 'cancelled') AS total
        FROM orders o
        LEFT JOIN users u ON u.id = o.waiter_id
        WHERE o.table_id = ? AND o.status IN ('open','sent','served')
        ORDER BY o.id DESC
        LIMIT 1
        """, (table["id"],),
    ).fetchone()

    return render_template(
        "public/table_quick.html",
        table=table,
        active_order=active_order,
    )