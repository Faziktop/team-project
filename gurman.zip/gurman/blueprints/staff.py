"""Персонал: сотрудники и график смен."""
from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for,
)

from werkzeug.security import check_password_hash

from config import DATE_RE, PHONE_RE, ROLE_ACCOUNTANT, ROLE_ADMIN
from db import get_db
from utils import log_action, money, roles_required, safe_float


staff = Blueprint("staff", __name__, url_prefix="/staff")


@staff.route("/")
@roles_required(ROLE_ADMIN, ROLE_ACCOUNTANT)
def list_employees():
    db = get_db()
    rows = db.execute("SELECT * FROM employees ORDER BY full_name").fetchall()
    total_fund = money(sum(e["salary"] for e in rows if e["is_active"]))
    return render_template("staff/list.html", employees=rows, total_fund=total_fund)


@staff.route("/new", methods=("GET", "POST"))
@roles_required(ROLE_ADMIN)
def new_employee():
    if request.method == "POST":
        full_name = (request.form.get("full_name") or "").strip()
        position = (request.form.get("position") or "").strip()
        phone = (request.form.get("phone") or "").strip()
        hired_at = request.form.get("hired_at", "")
        salary_raw = safe_float(request.form.get("salary"), min_=0, max_=10_000_000)
        db = get_db()

        if not full_name or not position:
            flash("Укажите ФИО и должность.", "error")
        elif len(full_name) > 200 or len(position) > 100:
            flash("Слишком длинное значение.", "error")
        elif salary_raw is None:
            flash("Некорректный оклад.", "error")
        elif phone and not PHONE_RE.match(phone):
            flash("Некорректный телефон.", "error")
        elif hired_at and not DATE_RE.match(hired_at):
            flash("Некорректная дата приёма.", "error")
        else:
            db.execute(
                "INSERT INTO employees (full_name, position, phone, hired_at, salary) "
                "VALUES (?, ?, ?, ?, ?)",
                (full_name, position, phone or None, hired_at or None, salary_raw),
            )
            log_action(f"Принят сотрудник «{full_name}» ({position})",
                       entity_type="employee")
            flash("Сотрудник добавлен.", "success")
            return redirect(url_for("staff.list_employees"))
    return render_template("staff/employee_form.html")


@staff.route("/<int:employee_id>/toggle", methods=("POST",))
@roles_required("admin")
def toggle_employee(employee_id):
    db = get_db()

    # FIX C-2: симметрия с auth.toggle_user — re-auth обязателен.
    # При угоне admin-сессии без пароля нельзя уволить штат.
    admin_password = request.form.get("admin_password") or ""
    if not admin_password:
        flash("Введите текущий пароль для подтверждения.", "error")
        return redirect(url_for("staff.list_employees"))

    row = db.execute("SELECT password_hash FROM users WHERE id = ?",
                     (g.user["id"],)).fetchone()
    if not row or not check_password_hash(row["password_hash"], admin_password):
        log_action("Re-auth провал при toggle_employee",
                   entity_type="employee", entity_id=employee_id)
        flash("Неверный пароль. Действие отклонено.", "error")
        return redirect(url_for("staff.list_employees"))

    emp = db.execute("SELECT id FROM employees WHERE id = ?",
                     (employee_id,)).fetchone()
    if not emp:
        flash("Сотрудник не найден.", "error")
        return redirect(url_for("staff.list_employees"))

    db.execute("UPDATE employees SET is_active = 1 - is_active WHERE id = ?",
               (employee_id,))
    log_action(f"Изменён статус занятости сотрудника #{employee_id}",
               entity_type="employee", entity_id=employee_id)
    return redirect(url_for("staff.list_employees"))

@staff.route("/schedule")
@roles_required("admin", "accountant")
def schedule():
    db = get_db()
    rows = db.execute(
        """
        SELECT s.*, e.full_name, e.position
        FROM schedule s JOIN employees e ON e.id = s.employee_id
        ORDER BY s.work_date, s.shift_start
        """
    ).fetchall()
    employees = db.execute(
        """
        SELECT e.*, u.ical_token
        FROM employees e
        LEFT JOIN users u ON u.id = e.user_id
        WHERE e.is_active = 1
        ORDER BY e.full_name
        """
    ).fetchall()
    return render_template("staff/schedule.html",
                           schedule=rows, employees=employees)


@staff.route("/schedule/new", methods=("POST",))
@roles_required("admin")
def new_shift():
    db = get_db()
    employee_id = request.form.get("employee_id", type=int)
    work_date = request.form.get("work_date")
    shift_start = request.form.get("shift_start")
    shift_end = request.form.get("shift_end")

    if not employee_id or not work_date or not shift_start or not shift_end:
        flash("Заполните все поля.", "error")
        return redirect(url_for("staff.schedule"))
    if not DATE_RE.match(work_date):
        flash("Некорректная дата.", "error")
        return redirect(url_for("staff.schedule"))
    if shift_start >= shift_end:
        flash("Окончание должно быть позже начала.", "error")
        return redirect(url_for("staff.schedule"))

    # FIX A09-3: BEGIN IMMEDIATE — SELECT пересечений + INSERT
    # должны быть атомарны, иначе два админа могут параллельно
    # создать пересекающиеся смены одному сотруднику.
    db.execute("BEGIN IMMEDIATE")
    try:
        emp = db.execute("SELECT id FROM employees WHERE id = ?",
                         (employee_id,)).fetchone()
        if not emp:
            db.execute("ROLLBACK")
            flash("Сотрудник не найден.", "error")
            return redirect(url_for("staff.schedule"))

        overlap = db.execute(
            """SELECT id FROM schedule
               WHERE employee_id = ? AND work_date = ?
                 AND NOT (shift_end <= ? OR shift_start >= ?)""",
            (employee_id, work_date, shift_start, shift_end),
        ).fetchone()
        if overlap:
            db.execute("ROLLBACK")
            flash("У сотрудника уже есть пересекающаяся смена в этот день.",
                  "error")
            return redirect(url_for("staff.schedule"))

        db.execute(
            "INSERT INTO schedule (employee_id, work_date, shift_start, shift_end) "
            "VALUES (?, ?, ?, ?)",
            (employee_id, work_date, shift_start, shift_end),
        )
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    log_action(f"Добавлена смена для сотрудника #{employee_id} на {work_date}",
               entity_type="employee", entity_id=employee_id)
    return redirect(url_for("staff.schedule"))

@staff.route("/schedule/<int:shift_id>/remove", methods=("POST",))
@roles_required("admin")
def remove_shift(shift_id):
    db = get_db()
    db.execute("DELETE FROM schedule WHERE id = ?", (shift_id,))
    log_action(f"Удалена смена #{shift_id}", entity_type="schedule",
               entity_id=shift_id)
    return redirect(url_for("staff.schedule"))

# ---------------------------------------------------------------------------
# iCal-экспорт графика смен
# ---------------------------------------------------------------------------
import secrets
from datetime import datetime, timedelta

from flask import Response

from utils.schedule_ical import build_ical, make_event


@staff.route("/schedule/ical/subscribe", methods=("POST",))
@roles_required(ROLE_ADMIN)
def ical_subscribe():
    """Сгенерировать (или перегенерировать) токен для сотрудника."""
    db = get_db()
    employee_id = request.form.get("employee_id", type=int)
    if not employee_id:
        flash("Не указан сотрудник.", "error")
        return redirect(url_for("staff.schedule"))

    emp = db.execute(
        "SELECT id, user_id FROM employees WHERE id = ?", (employee_id,)
    ).fetchone()
    if not emp or not emp["user_id"]:
        flash("У сотрудника нет привязанной учётной записи.", "error")
        return redirect(url_for("staff.schedule"))

    token = secrets.token_urlsafe(32)
    db.execute(
        "UPDATE users SET ical_token = ? WHERE id = ?",
        (token, emp["user_id"]),
    )
    log_action(f"Сгенерирован iCal-токен для сотрудника #{employee_id}",
               entity_type="employee", entity_id=employee_id)
    flash("Ссылка на календарь создана (старая, если была, отозвана).",
          "success")
    return redirect(url_for("staff.schedule"))


@staff.route("/schedule/ical/revoke", methods=("POST",))
@roles_required(ROLE_ADMIN)
def ical_revoke():
    """Отозвать токен — ссылка перестаёт работать."""
    db = get_db()
    employee_id = request.form.get("employee_id", type=int)
    if not employee_id:
        flash("Не указан сотрудник.", "error")
        return redirect(url_for("staff.schedule"))

    emp = db.execute(
        "SELECT user_id FROM employees WHERE id = ?", (employee_id,)
    ).fetchone()
    if emp and emp["user_id"]:
        db.execute("UPDATE users SET ical_token = NULL WHERE id = ?",
                   (emp["user_id"],))
        log_action(f"Отозван iCal-токен сотрудника #{employee_id}",
                   entity_type="employee", entity_id=employee_id)
    return redirect(url_for("staff.schedule"))


@staff.route("/schedule.ics")
def ical_feed():
    """Публичный .ics-фид для конкретного пользователя по токену.

    Без @login_required: Google Calendar и Яндекс.Календарь не умеют
    логиниться. Токен — единственный секрет; при утечке сотрудник
    просит админа перегенерировать ссылку.
    """
    db = get_db()
    token = (request.args.get("token") or "").strip()
    if not token or len(token) < 20:
        return Response("Not Found", status=404, mimetype="text/plain")

    user = db.execute(
        "SELECT u.id, u.full_name, u.ical_token "
        "FROM users u "
        "WHERE u.ical_token = ? AND u.is_active = 1",
        (token,),
    ).fetchone()
    if not user:
        # Намеренно 404, а не 401: не подсказываем, что токен «почти верный».
        return Response("Not Found", status=404, mimetype="text/plain")

    rows = db.execute(
        """
        SELECT s.work_date, s.shift_start, s.shift_end,
               e.full_name, e.position
        FROM schedule s
        JOIN employees e ON e.id = s.employee_id
        WHERE e.user_id = ?
        ORDER BY s.work_date, s.shift_start
        """,
        (user["id"],),
    ).fetchall()

    events = []
    for r in rows:
        # Ограничиваем разумным окном, чтобы фид не разрастался.
        # .ics отдаёт все смены — за год их немного.
        dtstart = f"{r['work_date']} {r['shift_start']}"
        dtend = f"{r['work_date']} {r['shift_end']}"

        # Защита от ночных смен: если конец <= начала, считаем что
        # смена переходит на следующий день.
        if r["shift_end"] <= r["shift_start"]:
            d = datetime.strptime(r["work_date"], "%Y-%m-%d") + timedelta(days=1)
            dtend = f"{d.strftime('%Y-%m-%d')} {r['shift_end']}"

        events.append(make_event(
            uid=f"shift-{r['work_date']}-{r['shift_start']}-{user['id']}@gurman",
            summary=f"Смена {r['shift_start']}–{r['shift_end']} · {r['position']}",
            description=(
                f"Сотрудник: {r['full_name']}\n"
                f"Должность: {r['position']}\n"
                f"Ресторан «Гурман»"
            ),
            location="Ресторан «Гурман»",
            dtstart=dtstart,
            dtend=dtend,
        ))

    body = build_ical(
        events,
        calendar_name=f"Смены · {user['full_name']}",
    )

    resp = Response(body, mimetype="text/calendar; charset=utf-8")
    resp.headers["Content-Disposition"] = (
        'inline; filename="gurman-schedule.ics"'
    )
    # Кэшируем 5 минут: календари опрашивают фид часто,
    # но нам не нужно отдавать свежие данные на каждый запрос.
    resp.headers["Cache-Control"] = "private, max-age=300"
    return resp