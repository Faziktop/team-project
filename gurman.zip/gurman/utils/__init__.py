"""Пакет утилит.

Реэкспортирует публичный API, чтобы существующие импорты
`from utils import safe_int, money, ...` продолжали работать без
изменений. Модуль `utils.py` (единый файл) удалён в пользу пакета.
"""
from utils.audit import (
    default_landing, log_action, verify_admin_password,
)
from utils.decorators import login_required, roles_required
from utils.money import money
from utils.parsing import safe_float, safe_int
from utils.password_policy import (
    get_dummy_hash, password_ok, warmup_dummy_hash,
)
from utils.urls import is_safe_url
from utils.schedule_ical import build_ical, make_event
from utils.excel import (
    orders_workbook, reports_workbook, stock_workbook,
)
__all__ = [
    "money",
    "safe_float",
    "safe_int",
    "password_ok",
    "get_dummy_hash",
    "warmup_dummy_hash",
    "is_safe_url",
    "login_required",
    "roles_required",
    "log_action",
    "verify_admin_password",
    "default_landing",
    "build_ical",
    "make_event",
    "reports_workbook",
    "stock_workbook",
    "orders_workbook",
]