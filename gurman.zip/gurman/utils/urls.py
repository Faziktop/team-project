"""Проверка безопасных редиректов."""
from urllib.parse import unquote, urlparse


def is_safe_url(target: str) -> bool:
    """Разрешает только относительные пути вида /path?query."""
    if not target or not isinstance(target, str):
        return False
    if len(target) > 2000:
        return False

    decoded = unquote(target)
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in decoded):
        return False
    if "\\" in decoded:
        return False
    if decoded.startswith("//"):
        return False

    p = urlparse(decoded)
    if p.scheme or p.netloc:
        return False
    if not p.path.startswith("/") or p.path.startswith("//"):
        return False

    segments = p.path.split("/")
    if ".." in segments:
        return False
    if "//" in p.path:
        return False
    return True