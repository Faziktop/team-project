"""Аудит и re-auth."""
from flask import current_app, g, request, url_for
from werkzeug.security import check_password_hash

from db import get_db


def log_action(action, entity_type=None, entity_id=None):
    """Запись в журнал аудита. Не должна ломать основную операцию."""
    try:
        db = get_db()
        user_id = g.user["id"] if g.user else None
        ip = request.remote_addr if request else None
        db.execute(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id, ip) "
            "VALUES (?, ?, ?, ?, ?)",
            (user_id, action, entity_type, entity_id, ip),
        )
    except Exception:
        # N-7: единственный уровень обработки, но с гарантированным логом.
        current_app.logger.exception("Ошибка записи в аудит")


def verify_admin_password(db, user_id: int, password: str) -> bool:
    """Re-auth: проверяет, что пароль принадлежит указанному пользователю."""
    row = db.execute("SELECT password_hash FROM users WHERE id = ?",
                     (user_id,)).fetchone()
    if not row:
        return False
    return check_password_hash(row["password_hash"], password or "")


def default_landing(role: str | None = None) -> str:
    """URL стартовой страницы после входа."""
    return url_for("index")