"""Безопасный парсинг чисел из форм."""
import math


def safe_float(raw, *, min_=None, max_=None, default=None):
    """Безопасный float. None при ошибке/NaN/Inf/выходе за границы."""
    if raw is None:
        return default
    try:
        v = float(str(raw).replace(",", ".").strip())
    except (TypeError, ValueError):
        return None
    if not math.isfinite(v):
        return None
    if min_ is not None and v < min_:
        return None
    if max_ is not None and v > max_:
        return None
    return v


def safe_int(raw, *, min_=None, max_=None, default=None):
    """Безопасный int. '1e5', '1.5', 'nan' — отсекается."""
    if raw is None:
        return default
    try:
        v = int(str(raw).strip())
    except (TypeError, ValueError):
        return None
    if min_ is not None and v < min_:
        return None
    if max_ is not None and v > max_:
        return None
    return v