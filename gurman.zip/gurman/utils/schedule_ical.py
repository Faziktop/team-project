"""Генерация iCalendar (RFC 5545) для графика смен.

Экспортирует:
    build_ical(events) -> str
    make_event(...)    -> dict

Событие — dict с ключами:
    uid, summary, description, location, dtstart, dtend
dtstart/dtend — "YYYY-MM-DD HH:MM" (локальное время ресторана).
Часовой пояс фиксированный: Europe/Moscow.
"""
from datetime import datetime

# Часовой пояс фиксирован — ресторан один, TZ-конфиг не нужен.
TZID = "Europe/Moscow"


def _escape(text: str) -> str:
    """RFC 5545: экранирование ; , \\ и переводов строк."""
    if not text:
        return ""
    return (
        text.replace("\\", "\\\\")
            .replace(";", "\\;")
            .replace(",", "\\,")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
    )


def _fold(line: str) -> str:
    """RFC 5545: строки длиннее 75 октетов складываются с пробелом."""
    if len(line) <= 75:
        return line
    out = [line[:75]]
    rest = line[75:]
    while rest:
        out.append(" " + rest[:74])
        rest = rest[74:]
    return "\r\n".join(out)


def _fmt_dt(value: str, tzid: str = TZID) -> str:
    """'2026-10-16 10:00' → '20261016T100000'.

    TZ-суффикс не добавляем — вместо него используем параметр
    TZID=... в свойстве DTSTART;TZID=Europe/Moscow:...
    """
    dt = datetime.strptime(value, "%Y-%m-%d %H:%M")
    return dt.strftime("%Y%m%dT%H%M%S")


def make_event(*, uid: str, summary: str, dtstart: str, dtend: str,
               description: str = "", location: str = "") -> dict:
    """Собрать событие для передачи в build_ical()."""
    return {
        "uid": uid,
        "summary": summary,
        "description": description,
        "location": location,
        "dtstart": dtstart,
        "dtend": dtend,
    }


def build_ical(events: list[dict], *, calendar_name: str = "График смен",
               prodid: str = "-//Gurman AIS//Schedule//RU") -> str:
    """Собрать .ics-файл из списка событий.

    Возвращает строку с CRLF-разделителями (RFC 5545 требует CRLF).
    """
    now_stamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        f"PRODID:{prodid}",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        f"X-WR-CALNAME:{_escape(calendar_name)}",
        f"X-WR-TIMEZONE:{TZID}",
    ]

    # VTIMEZONE — минимально корректный блок для Europe/Moscow.
    # Без него Google Calendar сам подставит UTC+03:00, но
    # Outlook иногда жалуется, поэтому пишем явно.
    lines += [
        "BEGIN:VTIMEZONE",
        f"TZID:{TZID}",
        "BEGIN:STANDARD",
        "DTSTART:19700101T000000",
        "TZOFFSETFROM:+0300",
        "TZOFFSETTO:+0300",
        "TZNAME:MSK",
        "END:STANDARD",
        "END:VTIMEZONE",
    ]

    for ev in events:
        uid = ev.get("uid") or f"{now_stamp}-{id(ev)}@gurman"
        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{now_stamp}",
            f"DTSTART;TZID={TZID}:{_fmt_dt(ev['dtstart'])}",
            f"DTEND;TZID={TZID}:{_fmt_dt(ev['dtend'])}",
            f"SUMMARY:{_escape(ev['summary'])}",
        ]
        if ev.get("description"):
            lines.append(f"DESCRIPTION:{_escape(ev['description'])}")
        if ev.get("location"):
            lines.append(f"LOCATION:{_escape(ev['location'])}")
        lines.append("END:VEVENT")

    lines.append("END:VCALENDAR")

    # Финальная склейка с CRLF и fold-ом для длинных строк.
    return "\r\n".join(_fold(line) for line in lines) + "\r\n"