"""Политика паролей и dummy-hash для timing-защиты."""
import re
import threading

from config import (
    _COMMON_PASSWORDS, _SEQ_SET, PASSWORD_MAX, PASSWORD_MIN,
)
from passwords import hash_password


def password_ok(pw: str, *, username: str = "", full_name: str = "") -> str | None:
    """Валидация пароля. Возвращает текст ошибки или None."""
    if not isinstance(pw, str):
        return "Некорректный пароль."
    if len(pw) < PASSWORD_MIN:
        return f"Пароль должен содержать минимум {PASSWORD_MIN} символов."
    if len(pw) > PASSWORD_MAX:
        return f"Пароль слишком длинный (максимум {PASSWORD_MAX})."
    if not re.search(r"[A-Za-z]", pw):
        return "Пароль должен содержать хотя бы одну букву."
    if not re.search(r"\d", pw):
        return "Пароль должен содержать хотя бы одну цифру."

    low = pw.lower()
    if low in _COMMON_PASSWORDS:
        return "Пароль слишком простой (в списке распространённых)."
    if username and username.lower() in low:
        return "Пароль не должен содержать логин."
    if full_name:
        for word in re.findall(r"[A-Za-zА-Яа-яЁё]{4,}", full_name.lower()):
            if word in low:
                return "Пароль не должен содержать имя/фамилию."
    for seq in _SEQ_SET:
        if seq in low:
            return "Пароль содержит тривиальную последовательность."
    if len(set(pw)) < 4:
        return "Пароль слишком однообразный."
    return None


_dummy_hash_cache: str | None = None
_dummy_hash_lock = threading.Lock()


def get_dummy_hash() -> str:
    global _dummy_hash_cache
    if _dummy_hash_cache is None:
        with _dummy_hash_lock:
            if _dummy_hash_cache is None:
                _dummy_hash_cache = hash_password(
                    "dummy-password-for-timing-only",
                )
    return _dummy_hash_cache


def warmup_dummy_hash() -> None:
    get_dummy_hash()