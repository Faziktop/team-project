"""Округление денег."""
from decimal import ROUND_HALF_UP, Decimal


def money(x) -> float:
    """Округление до копеек. NaN/Inf → 0.0."""
    if x is None:
        return 0.0
    try:
        d = Decimal(str(x))
    except Exception:
        return 0.0
    if not d.is_finite():
        return 0.0
    return float(d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))