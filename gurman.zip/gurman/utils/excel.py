"""Генерация XLSX через openpyxl. Возвращает BytesIO — для send_file."""
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


_HEADER_FILL = PatternFill("solid", fgColor="2F6FB0")
_HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
_TITLE_FONT = Font(bold=True, size=14)
_MONEY_FMT = '#,##0.00 ₽'


def _autosize(ws) -> None:
    """Подогнать ширину колонок под содержимое (max 40 символов)."""
    for col_idx, col in enumerate(ws.iter_cols(), start=1):
        max_len = 0
        for cell in col:
            v = cell.value
            if v is None:
                continue
            s = str(v)
            if len(s) > max_len:
                max_len = len(s)
        ws.column_dimensions[get_column_letter(col_idx)].width = \
            min(max_len + 2, 40)


def _write_title(ws, row: int, text: str) -> int:
    ws.cell(row=row, column=1, value=text).font = _TITLE_FONT
    return row + 2


def _write_header(ws, row: int, headers: list[str]) -> int:
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=row, column=i, value=h)
        c.fill = _HEADER_FILL
        c.font = _HEADER_FONT
        c.alignment = Alignment(horizontal="center", vertical="center")
    return row + 1


def _write_row(ws, row: int, values: list, *, money_cols: set[int] = frozenset()):
    for i, v in enumerate(values, start=1):
        c = ws.cell(row=row, column=i, value=v)
        if i in money_cols:
            c.number_format = _MONEY_FMT
    return row + 1


# ---------------------------------------------------------------------------
# Публичные фабрики
# ---------------------------------------------------------------------------
def reports_workbook(*, date_from: str, date_to: str,
                     revenue: dict, top_dishes: list,
                     daily_revenue: list, payroll: dict,
                     low_stock: list) -> BytesIO:
    """Собрать XLSX с отчётом: 4 листа."""
    wb = Workbook()

    # ---- Лист 1: Сводка ----
    ws = wb.active
    ws.title = "Сводка"
    r = _write_title(ws, 1, f"Финансовый отчёт за {date_from} – {date_to}")
    r = _write_header(ws, r, ["Показатель", "Значение"])
    r = _write_row(ws, r, ["Выручка за период", revenue.get("revenue", 0)],
                   money_cols={2})
    r = _write_row(ws, r, ["Оплаченных заказов", revenue.get("orders_count", 0)])
    cnt = revenue.get("orders_count") or 0
    avg = (revenue.get("revenue", 0) / cnt) if cnt else 0
    r = _write_row(ws, r, ["Средний чек", avg], money_cols={2})
    r = _write_row(ws, r, ["ФОТ / месяц", payroll.get("total", 0)],
                   money_cols={2})
    _autosize(ws)

    # ---- Лист 2: Топ блюд ----
    ws = wb.create_sheet("Топ блюд")
    r = _write_title(ws, 1, "Топ блюд по выручке")
    r = _write_header(ws, r, ["Блюдо", "Продано, шт", "Выручка"])
    for d in top_dishes:
        r = _write_row(ws, r,
                       [d["name"], d["qty_sold"], d["revenue"]],
                       money_cols={3})
    _autosize(ws)

    # ---- Лист 3: По дням ----
    ws = wb.create_sheet("По дням")
    r = _write_title(ws, 1, "Выручка по дням")
    r = _write_header(ws, r, ["Дата", "Выручка"])
    for d in daily_revenue:
        r = _write_row(ws, r, [d["day"], d["revenue"]], money_cols={2})
    _autosize(ws)

    # ---- Лист 4: Низкие остатки ----
    ws = wb.create_sheet("Низкие остатки")
    r = _write_title(ws, 1, "Товары ниже минимального остатка")
    r = _write_header(ws, r,
                      ["Товар", "Остаток", "Ед.", "Минимум", "Ед."])
    for i in low_stock:
        r = _write_row(ws, r, [
            i["name"], round(i["stock_qty"], 2), i["unit"],
            round(i["min_qty"], 2), i["unit"],
        ])
    _autosize(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def stock_workbook(ingredients: list) -> BytesIO:
    """XLSX по складу с подсветкой позиций ниже минимума."""
    from openpyxl.styles import PatternFill as PF
    red = PF("solid", fgColor="FBE9E7")

    wb = Workbook()
    ws = wb.active
    ws.title = "Склад"
    r = _write_title(ws, 1, "Остатки на складе")
    r = _write_header(ws, r,
                      ["Наименование", "Остаток", "Ед.", "Минимум", "Ед."])
    for i in ingredients:
        row_values = [
            i["name"], round(i["stock_qty"], 3), i["unit"],
            round(i["min_qty"], 3), i["unit"],
        ]
        r = _write_row(ws, r, row_values)
        if i["stock_qty"] <= i["min_qty"]:
            for col in range(1, 6):
                ws.cell(row=r - 1, column=col).fill = red
    _autosize(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def orders_workbook(orders: list, date_from: str, date_to: str) -> BytesIO:
    """XLSX со списком заказов за период."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Заказы"
    r = _write_title(ws, 1, f"Заказы за {date_from} – {date_to}")
    r = _write_header(ws, r, [
        "№", "Дата", "Стол", "Официант", "Гостей",
        "Статус", "Позиций", "Сумма",
    ])
    for o in orders:
        r = _write_row(ws, r, [
            o["id"], o["created_at"], o["table_number"] or "—",
            o["waiter_name"] or "—", o["guests"],
            o["status"], o["items_count"], o["total"],
        ], money_cols={8})
    _autosize(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf