"""Декораторы авторизации."""
import functools

from flask import flash, g, redirect, request, url_for

from config import ROLE_ADMIN
from utils.audit import log_action


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    """Декоратор доступа по ролям. Админ имеет доступ всегда."""
    def decorator(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("auth.login", next=request.path))
            if g.user["role"] not in roles and g.user["role"] != ROLE_ADMIN:
                log_action(
                    f"Отказ в доступе: {request.endpoint} (роль={g.user['role']})",
                    entity_type="access_denied",
                )
                flash("Недостаточно прав для выполнения этого действия.", "error")
                return redirect(url_for("index"))
            return view(*args, **kwargs)
        return wrapped
    return decorator